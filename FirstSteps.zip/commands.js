// A command has an arbitrary name, a regex or pattern, 
// and a script as a minimum.
// regex           A regex to match against
// pattern         An alternative to a regex, will be converted to a regex at runtime
//                 A command must have either a pattern or a regex
// objects         An array of matches in the regex (see wiki)
// script          This will be run on a successful match
// att             If there is no script, then this attribute on the object will be used
// nothingForAll   If the player uses ALL and there is nothing there, use this error message
// noTurnscripts   Set to true to prevent turnscripts firing even when this command is successful

"use strict";

function Cmd(name, hash) {
  this.name = name;
  this.objects = [];
  // This is the default script for commands
  this.script = function(cmd, objects) {
    var attName = cmd.att ? cmd.att : cmd.name.toLowerCase();
    var success = false;
    for (var i = 0; i < objects[0].length; i++) {
      if (!objects[0][i][attName]) {
        errormsg(ERR_GAME_BUG, CMD_NO_ATT_ERROR + " (" + objects[0][i].name + ").");
      }
      else {
        var result = printOrRun(objects[0][i], attName, (objects[0].length > 1 || parser.currentCommand.all));
        success = result || success;
      }
    }
    if (success) {
      updateUIItems();
      return (cmd.noTurnscripts ? SUCCESS_NO_TURNSCRIPTS : SUCCESS);
    }
    else {
      return FAILED; 
    }
  };
  for (var key in hash) {
    this[key] = hash[key];
  }
}

function ExitCmd(name, hash) {
  Cmd.call(this, name, hash);
  this.exitCmd = true;
  this.objects = [{ignore:true}, {ignore:true}, ],
  this.script = function(cmd, objects) {
    if (!hasExit(game.room, cmd.name)) {
      errormsg(ERR_PLAYER, CMD_NOT_THAT_WAY);
      return FAILED;
    }
    else {
      var ex = game.room[cmd.name];
      if (typeof ex == "string") {
        setRoom(ex);
        return SUCCESS;
      }
      else if (typeof ex === "function"){
        ex(game.room);
        return SUCCESS;
      }
      else if (typeof ex === "object"){
        var fn = ex.use;
        return fn(ex, cmd.name);
      }
      else {
        errormsg(ERR_GAME_BUG, CMD_UNSUPPORTED_DIR);
        return FAILED;
      }
    }
    
  };
}

var useWithDoor = function(ex) {
  var obj = w[ex.door];
  var doorName = ex.doorName ? ex.doorName : "door"
  if (!obj.closed) {
    setRoom(ex.name);
    return SUCCESS;
  }
  if (!obj.locked) {
    obj.closed = false;
    msg("You open the " + doorName + " and walk through.");
    setRoom(ex.name);
    return SUCCESS;
  }
  if (obj.testKeys()) {
    obj.closed = false;
    obj.locked = false;
    msg("You unlock the " + doorName + ", open it and walk through.");
    setRoom(ex.name);
    return SUCCESS;
  }        
  msg("You try the " + doorName + ", but it is locked.");
  return FAILED;
}


function VerbCmd(name, hash) {
  Cmd.call(this, name, hash);
  this.verb = true;
}

function AltCmd(name, altcmd, regex) {
  Cmd.call(this, name, {});
  this.altcmd = name;
  this.regex = regex;
}

function AltVerbCmd(name, altcmd, pattern) {
  Cmd.call(this, name, {});
  this.altcmd = name;
  this.pattern = pattern;
  this.verb = true;
}



var commands = [
  new Cmd('Help', {
    regex:/^help|\?$/,
    script:helpScript,
  }),    
  
  new Cmd('Look', {
    regex:/^l|look$/,
    script:function() {
      game.room.description();
      return SUCCESS_NO_TURNSCRIPTS;
    },
  }),
  new Cmd('Wait', {
    pattern:'wait;z',
    script:function() {
      return SUCCESS;
    },
  }),
  new Cmd('Brief', {
    pattern:'brief',
    script:function() {
      game.verbosity = BRIEF;
      metamsg("Game mode is now 'brief'; no room descriptions (except with LOOK).");
      return SUCCESS_NO_TURNSCRIPTS;
    },
  }),
  new Cmd('Terse', {
    pattern:'terse',
    script:function() {
      game.verbosity = TERSE;
      metamsg("Game mode is now 'terse'; room descriptions only shown on first entering and with LOOK.");
      return SUCCESS_NO_TURNSCRIPTS;
    },
  }),
  new Cmd('Verbose', {
    pattern:'verbose',
    script:function() {
      game.verbosity = VERBOSE;
      metamsg("Game mode is now 'verbose'; room descriptions shown everytme you enter a room.");
      return SUCCESS_NO_TURNSCRIPTS;
    },
  }),
  new Cmd('Inv', {
    regex:/^inventory|inv|i$/,
    script:function() {
      var listOfOjects = scope(isHeld);
      msg("You are carrying " + formatList(listOfOjects, {def:"a", joiner:" and", modified:true, nothing:"nothing"}) + ".");
      return SUCCESS_NO_TURNSCRIPTS;
    },
  }),
  new Cmd('Save', {
    regex:/^save$/,
    script:saveLoadScript,
  }),
  new Cmd('Save game', {
    regex:/^(save) (.+)$/,
    script:function(cmd, arr) {
      saveLoad.saveGame(arr[0]);
      return SUCCESS_NO_TURNSCRIPTS; 
    },
    objects:[
      {ignore:true},
      {text:true},
    ]
  }),
  new Cmd('Load', {
    regex:/^reload|load$/,
    script:saveLoadScript,
  }),
  new Cmd('Load game', {
    regex:/^(load|reload) (.+)$/,
    script:function(cmd, arr) {
      saveLoad.loadGame(arr[0]);
      return SUCCESS_NO_TURNSCRIPTS; 
    },
    objects:[
      {ignore:true},
      {text:true},
    ]
  }),
  new Cmd('Dir', {
    regex:/^dir|directory$/,
    script:function() {
      saveLoad.dirGame();
      return SUCCESS_NO_TURNSCRIPTS;
    },
  }),
  new Cmd('Delete game', {
    regex:/^(delete|del) (.+)$/,
    script:function(cmd, arr) {
      saveLoad.deleteGame(arr[0]);
      return SUCCESS_NO_TURNSCRIPTS; 
    },
    objects:[
      {ignore:true},
      {text:true},
    ]
  }),
  new Cmd('Map', {
    regex:/^map$/,
    script:function() {
      io.map();
      return SUCCESS_NO_TURNSCRIPTS;
    },
  }),
  new Cmd('test', {
    pattern:'test',
    script:function() {
      metamsg(JSON.stringify(w.background));
      return SUCCESS_NO_TURNSCRIPTS;
    },
  }),

  new Cmd('Examine', {
    regex:/^(examine|exam|ex|x) (.+)$/,
    att:'examine',
    objects:[
      {ignore:true},
      {scope:isPresent}
    ]
  }),
  new Cmd('Look at', {  // used for NPCs
    regex:/^(look at|look) (.+)$/,
    att:'examine',
    objects:[
      {ignore:true},
      {scope:isPresent}
    ]
  }),
  new Cmd('About', {   //used for spells
    regex:/^(about) (.+)$/,
    att:'examine',
    objects:[
      {ignore:true},
      {scope:isPresent}
    ]
  }),
  
  new Cmd('Take', {
    regex:/^(take|get|pick up) (.+)$/,
    objects:[
      {ignore:true},
      {scope:isHere, multiple:true},
    ],
  }),
  
  new Cmd('Drop', {
    regex:/^(drop) (.+)$/,
    objects:[
      {ignore:true},
      {scope:isHeld, multiple:true},
    ],
  }),
  
  new Cmd('Wear', {
    regex:/^(wear|don|put on) (.+)$/,
    objects:[
      {ignore:true},
      {scope:isHeld, multiple:true},
    ],
  }),
  
  new Cmd('Remove', {
    regex:/^(remove|doff|take off) (.+)$/,
    objects:[
      {ignore:true},
      {scope:isHeld, multiple:true},
    ],
  }),
  
  new Cmd('Read', {
    regex:/^(read) (.+)$/,
    objects:[
      {ignore:true},
      {scope:isHeld, multiple:true},
    ],
  }),
  
  new Cmd('Eat', {
    regex:/^(eat) (.+)$/,
    objects:[
      {ignore:true},
      {scope:isHeld, multiple:true},
    ],
  }),
  
  new Cmd('Turn on', {
    regex:/^(turn on|switch on) (.+)$/,
    att:"switchon",
    objects:[
      {ignore:true},
      {scope:isHeld, multiple:true},
    ],
  }),
  
  new Cmd('Turn off', {
    regex:/^(turn off|switch off) (.+)$/,
    att:"switchoff",
    objects:[
      {ignore:true},
      {scope:isHeld, multiple:true},
    ],
  }),
  
  new Cmd('Open', {
    regex:/^(open) (.+)$/,
    objects:[
      {ignore:true},
      {scope:isPresent, multiple:true},
    ],
  }),
  
  new Cmd('Close', {
    regex:/^(close) (.+)$/,
    objects:[
      {ignore:true},
      {scope:isPresent, multiple:true},
    ],
  }),
  
  new Cmd('Lock', {
    regex:/^(lock) (.+)$/,
    objects:[
      {ignore:true},
      {scope:isPresent, multiple:true},
    ],
  }),
  
  new Cmd('Unlock', {
    regex:/^(unlock) (.+)$/,
    objects:[
      {ignore:true},
      {scope:isPresent, multiple:true},
    ],
  }),
  
  new Cmd('Use', {
    regex:/^(use) (.+)$/,
    objects:[
      {ignore:true},
      {scope:isPresent, multiple:true},
    ],
  }),
  
  new Cmd('Talk to', {
    regex:/^(talk to|talk|speak to|speak|converse with|converse) (.+)$/,
    att:"speakto",
    objects:[
      {ignore:true},
      {scope:isHere},
    ]
  }),

  new Cmd('Put/in', {
    regex:/^(put|place|drop) (.+) (in to|into|in) (.+)$/,
    objects:[
      {ignore:true},
      {scope:isHeld, multiple:true},
      {ignore:true},
      {scope:isPresent},
    ],
    script:function(cmd, objects) {
      var success = false;
      var container = objects[1][0];
      if (!container.container) {
        errormsg(ERR_PLAYER, CMD_NOT_CONTAINER(container));
        return FAILED; 
      }
      for (var i = 0; i < objects[0].length; i++) {
        var flag = true;
        if (container.checkCapacity) {
          flag = container.checkCapacity(objects[0][i]);
        }
        if (flag) {
          if (objects[0][i].loc != game.player.name) {
            CMD_NOT_CARRYING(objects[0][i]);
          }
          else {
            objects[0][i].loc = container.name;
            msg(prefix(objects[0][i], objects[0].length > 1 || parser.currentCommand.all) + CMD_DONE);
            success = true;
          }
        }
      }
      if (success) { updateUIItems(); }
      return success ? SUCCESS : FAILED; 
    },
  }),
  


  new Cmd('Ask/about', {
    regex:/^(ask) (.+) (about) (.+)$/,
    script:function(cmd, arr) {
      success = arr[0][0].askabout(arr[1]);
//      msg("You ask " + arr[0][0].name + " about " + arr[1] + ".*");
      return success ? SUCCESS : FAILED; 
    },
    objects:[
      {ignore:true},
      {scope:isHere},
      {ignore:true},
      {text:true},
    ]
  }),
  
  
  
  new Cmd('Inspect', {
    regex:/^(inspect) (.+)$/,
    script:function(cmd, arr) {
      if (DEBUG) {
        var item = arr[0][0];
        debugmsg(0, "Name: " + item.name);
        for (var key in item) {
          if (item.hasOwnProperty(key)) {
             debugmsg(0, "--" + key + ": " + item[key]);
          }
        }        
      }
      else {
        errormsg(ERR_PLAYER, "Debug commands are not available.");
      }
      return SUCCESS_NO_TURNSCRIPTS; 
    },
    objects:[
      {ignore:true},
      {scope:isInWorld},
    ]
  }),
];

    


