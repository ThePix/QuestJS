"use strict"

register('flora', {
  book:'A Midsummer Night\'s Dream',
  uniform:'a green and purple school uniform that feels strangely comfortable, even if it looks appalling',
  smell:'The room smells quite nice, full of blossoms and springtime.',
  listen:'If she strains, Mandy can hear a quiet humming, like a bee maybe.',
  floor:"The floor is a lattice of wrought iron, painted white, and flaking in a few places.",
  walls:"The walls are windows, in white frames.",
  ceiling:"The walls arched over to form the ceiling.",
})














createRoom("greenhouse_west", {
  todo:'Room description needs work.',
  windowsface:'north',
  alias:'west end of the greenhouse',
  headingAlias:'The Greenhouse (West)',
  seenFlag:false,
  desc:"{floraDesc}All manner of plants are growing, but it seems the gardener has made some selections, as all the flowers are red. Mandy cannot identify many of them, but can see poppies, marigolds and chrysanthemums. No carnations, as far as she can see. {once:Mandy remembers the roses in the garden; odd that they never flower, and yet here nearly everything is in flower. }Even the trees have red flowers. She recognises a bottlebush tree, though much bigger than the one her father has and not currently in bloom.{floraFlowerBed} Nearby, bolted to the west wall, is a huge metal box that stretches up about three stories.",
  west:new Exit("steam_hall"),
  east:new Exit("greenhouse_east"),
  climb:new Exit("_", {
    alsoDir:['up'],
    isHidden() { return (w.grown_tamarind_tree.growthTime < 9) },
    simpleUse:function(char) {
      if (char === w.Patch) {
        if (w.grown_tamarind_tree.growthTime < 9) return falsemsg("Patch looks around, confused, wondering what he should be climbing.")
        if (w.Patch.huggingTree) return falsemsg("'Climb the stupid tree,' says Mandy. Patch looks forlornly up the tree he is hugging.")
        let s = "Patch eyes up "
        if (w.grown_tamarind_tree.seedsPlanted === 1) {
          s += "the tamarind tree"
        }
        else {
          s += "one of the tamarind trees"
        }
          
        s += " , then steps closer, putting both arms round it. He pauses, and looks up, then down again, then up again. Apparently, climbing is not his thing."
        msg(s)
        w.Patch.huggingTree = true
        return true
      }
      
      if (w.grown_tamarind_tree.seedsPlanted === 0) return falsemsg("Mandy looks around, but there is nothing suitable to climb here.")
      if (w.hourglass.active) return falsemsg("Mandy looks at the rapidly grow tamarind plant thoughtfully. If she grabs on to it now, it will take her up with it as it grows! Steps closer, and her foot starts to blur, and feel numb. A moment later she is feeling nauseated. She steps back, trying to catch her breath. Perhaps not such a great idea...")
      if (w.grown_tamarind_tree.growthTime < 9) return falsemsg("Mandy looks at the {nv:item:grow:false:count_this} thoughtfully. If {nv:item:were} more substantial, she could climb {sb:item}.", {item:w.grown_tamarind_tree, count_this:'seedsPlanted'})
      if (w.grown_tamarind_tree.growthTime < 12) {
        msg("Mandy appraises the tree. It has been a while, but she can climb that. She grabs a lower branch, and hauls herself up.")
        player.moveChar(new Exit('up_a_tree', this))
        return true
      }
      if (w.Patch.isHere() && w.Patch.huggingTree) {
        msg("Mandy appraises the tree, with Patch still hugging it. She could use Patch to get up it. 'Er, just, hold still,' she tells him, as she grabs his solid arm, and starts to haul herself up. 'And keep looking downwards!' She pulls herself up onto his shoulder, and from there she grabs a lower branch, and hauls herself up.")
        player.moveChar(new Exit('up_a_tall_tree', this))
        return true
      }
      if (w.grown_tamarind_tree.seedsPlanted > 5) {
        msg("Mandy appraises the tangle of trees... The way they have knotted together should make climbing them, well, not exactly easy, but possible. She grabs a trunk that has bend almost horizontal, and pulls herself up. From there, she can reach another, not quite so flat, and up further into the trees.")
        player.moveChar(new Exit('up_a_tall_tree', this))
        return true
      }
      
      if (w.grown_tamarind_tree.seedsPlanted > 1) return falsemsg("Mandy looks up at the trees; they are certainly high enough that if she could climb them, she could reach across to the top of the metal box, but they are too tall to climb. The lowest branches are way out of reach.")
      return falsemsg("Mandy looks up at the tree; it is certainly high enough that if she could climb it, she could reach across to the top of the metal box, but it is too tall to climb. The lowest branches are way out of reach.")
    },

  }),
  scenery:[
    { alias:['poppies', 'poppy'], examine:'There is a large flower bed with poppies growing. They look slightly past their prime; a little wilted.' },
    { alias:'marigolds', examine:'There are at least three cultivars of marigolds: one has flowers with a yellow centre; another has petals fringed with yellow; and a third is plain red.' },
    { alias:'chrysanthemums', examine:'As she looks closer, she wonders if these are actually carnations.' },
    { alias:'carnations', examine:'She cannot decide if they are chrysanthemums or carnations.' },
    { alias:'bottlebush tree', examine:'The bottlebush tree is about five meters tall; a straight trunk rising a meter or so to a mass of leaves and red flowers.' },
  ],
})
createItem("poppies", {
  loc:"greenhouse_west",
  synonyms:['poppy'],
  scenery:true,
  smell:"Mandy wonders how the poppies smell, and is about to take a sniff when she remembers that scene in the Wizard of Oz. Probably better not to risk it.",
  pronouns:lang.pronouns.plural,
  examine:function(options) { return w.portraits_west.examine(options) },
})
tp.addDirective("floraFlowerBed", function(arr, params) {
  let s = " Mandy can see a patch of bare earth"
  if (arr[0]) s += " down below"
  s += ", with a pedestal beside it."
  if (w.hourglass.loc === 'pedestal') s += " There is {select:hourglass:size:::::a tiny:an:a large:} hourglass on the pedestal."
  if (w.grown_tamarind_tree.growthTime === 0) return s

  s += "She can see {nm:item:count:false:count_this}."
  if (w.grown_tamarind_tree.seedsPlanted > 5) {
    if (w.grown_tamarind_tree.growthTime > 8) {
      s += ' The trees have become tangled together, and look a like freaky mutants to Mandy.'
    }
    else if (w.grown_tamarind_tree.growthTime > 5) {
      s += ' The plants are entwined around each other.'
    }
  }
  return processText(s, {item:w.grown_tamarind_tree, count_this:'seedsPlanted'}) 
})
tp.addDirective("floraDesc", function(arr, params) {
  if (w.greenhouse_west.seenFlag) return ''
  w.greenhouse_west.seenFlag = true
  return 'Just for a moment, Mandy thinks she is outside - all she can see is trees, bushes and plants. But no, above there is a roof, and walls can be seen all around her; this is a greenhouse. '
})

createItem("metal_box", {
  isLocatedAt:function(loc) { return loc === 'greenhouse_west' || loc === 'greenhouse_catwalk_west' },
  alias:'metal box',
  scenery:true,
  examine:"Looking closer, Mandy can see that the metal box is brass plating around a mechanism or device of some sort. It is quite smooth for about four metres of its height, but above that she can see the open framework{if:lift:getTransitDestLocation:steam_control_room: and Mandy can see a cage inside it}."
})

createItem("pedestal", SURFACE(), {
  loc:'greenhouse_west',
  scenery:true,
  examine:function() {
    let s = 'The pedestal is made of pale grey stone, and is about waist height.'
    const contents = this.getContents()
    if (contents.length !== 0) {
      msg(s + ' There {cj:item:be} {nm:item:a} on it.', {item:contents[0]})
    }
    else {
      msg(s)
    }
  },
  testDropIn:function(options) {
    const contents = this.getContents()
    if (contents.length === 0) return true
    return falsemsg("Mandy thought about putting {nm:o1:the} on the pedestal. Of course, she would have to take {nm:o2:the} off it first.", {o1:options.item, o2:contents[0]})
  },
})

createItem("hourglass", SIZE_CHANGING(), {
/*
Can vary in size from 4 to 7; can be filled when 7 but not taken
fillState can be from 1 to 5
max number of grow turns is 13
*/
  loc:'pedestal',
  synonyms:['bulb'],
  fillState:1,  // max is 5
  state:0,
  indefArticle:'an',
  getIncrement:function() { 
    if (this.size === 4) return 100
    if (this.size === 5) return 100 / (this.fillState / 3 + 1)
    if (this.size === 6) return 100 / (this.fillState * 2 + 2)
  },
  
  desc4:"The hourglass has two connected glass bulbs, with a small amount of sand in the lower one, inside a delicate wooden frame. It is about the size of a thimble.",
  desc5:"The hourglass has two connected glass bulbs, with a small amount of sand in the lower one, inside a wooden frame, and is about as tall as her hand in long. There is a small protrusion on one bulb, near where they join. {hourglass}",
  desc6:"The hourglass has two connected glass bulbs, with a small amount of sand in the lower one, inside a sturdy wooden frame. One bulb has a small opening near where the bulbs join, with a tap. The hourglass is about waist height.{hourglass}",
  desc7:"The hourglass towers over Mandy; each bulb is as tall as she is. The lower bulbs has a large opening at the top, with a tap.{hourglass}",
  protrusionDescriptions:[
    '','','','',
    'Mandy can just about feel there is something there; a slight point on the otherwise smooth surface of the tiny glass bulb.',
    'The protrusion is a tiny tap.',
    'The protrusion is a small opening with a simple tap.',
    'The protrusion is a large opening in the bulb. There is a simple tap to open and close it.{ifNot:protrusion:closed: The tap is open.}',
  ],
  afterMove:function(options) {
    if (options.fromLoc === "pedestal") {
      w.grown_tamarind_tree.magicGrowthEnd()
    }
    if (options.toLoc === "pedestal") {
      this.activate()
    }
  },
  fill:'Mandy considers filling the hourglass - but then it would not work. Perhaps if she could pour something into it?',
  turn:function() {
    if (w.Patch.huggingTree) {
      msg("Patch steps away from the tree, perhaps sensing something is about to happen.")
      w.Patch.huggingTree = false
    }
    if (w.grown_tamarind_tree.growthTime > 0) {
      let s
      if (w.protrusion.closed) {
        s = "Mandy picks up the hourglass to turn it over."
      }
      else {
        w.protrusion.closed = true
        s = "Mandy closes the tap of the hourglass, picks it up to turn it over."
      }
      s += " As she does, {nv:item:wither} away to nothing."
      if (doOnce(this, 'flagWithered')) s += " 'Shit...' she mutters in disappointment."
      s += " She turns the hourglass over, and puts it down again."
      w.grown_tamarind_tree.seedsPlanted = 0
      w.grown_tamarind_tree.growthTime = 0
      msg(s, {item:w.grown_tamarind_tree})
    }
    else {
      if (w.protrusion.closed) {
        msg("Mandy turns the hourglass over.")
      }
      else {
        w.protrusion.closed = true
        msg("Mandy closes the tap of the hourglass, then turns it over.")
      }
    }
    this.state = 100 - this.state + this.getIncrement()
    if (this.loc === 'pedestal') this.activate()
    return true
  },
  
  activate:function() {
    this.active = true
    w.grown_tamarind_tree.seedsPlanted = w.tamarind_seed.countAtLoc("bare_earth")
    w.grown_tamarind_tree.update()
    w.tamarind_seed.takeFrom("bare_earth", w.grown_tamarind_tree.seedsPlanted)
  },
  eventPeriod:1,
  eventIsActive:function() { return this.state > 0 },
  eventScript:function() {
    this.state -= this.getIncrement()
    if (this.state > 0) {
      msg("The upper bulb in the hourglass is about " + Math.round(this.state) + "% full.")
      if (this.loc === "pedestal") w.grown_tamarind_tree.magicGrowth()
    }
    else {
      msg("The upper bulb in the hourglass is now empty.")
      this.active = false
      if (this.state < 0) this.state = 0
      //w.grown_tamarind_tree.magicGrowthEnd()
    }
  },
  sink:function(fluid, char, vessel) {
    if (this.size < 7) return falsemsg("Mandy thinks about getting the sand into the hourglass... There is no way she is getting it though that narrow opening.")
    if (w.protrusion.closed) {
      msg("Mandy opens the tap, and carefully empties {nm:item:the} into the huge hourglass.", {item:vessel} )
      w.protrusion.closed = false
    }
    else {
      msg("Mandy carefully empties {nm:item:the} into the huge hourglass.", {item:vessel} )
    }
    if (w.chamber_pot.size > 4) this.fillState += w.chamber_pot.size === 5 ? 1 : 5
    if (this.fillState > 5) this.fillState = 5
    return true
  },
  open:function(options) { w.protrusion.open(options) },
  close:function(options) { w.protrusion.close(options) },
})
w.hourglass.maxsize = 7
createItem("protrusion", COMPONENT("hourglass"), OPENABLE(), {
  examine:"{select:hourglass:protrusionDescriptions:size}",
  synonyms:['tap'],
  msgOpen:'Mandy opens the tap on the side of the hourglass bulb.',
  msgClose:'Mandy closes the tap on the side of the hourglass bulb.',
})
tp.addDirective("hourglass", function(arr, params) {
  if (w.hourglass.state > 0) {
    return "The upper bulb in the hourglass is about " + Math.round(w.hourglass.state) + "% full."
  }
  else if (w.hourglass.fillState === 5) {
    return "The upper bulb in the hourglass is empty, the bottom full."
  }
  else if (w.hourglass.fillState === 1) {
    return "The upper bulb in the hourglass is empty, but even so the lower bulb is only about a fifth full."
  }
  else {
    return "The upper bulb in the hourglass is empty, but even so he lower bulb is only " + lang.toWords(w.hourglass.fillState) + " fifths full."
  }
})

createItem("bare_earth", CONTAINER(), {
  loc:'greenhouse_west',
  scenery:true,
  seedsPlanted:0,
  synonyms:['ground'],
  examine:"{floraFlowerBed}",
  testDropIn:function(options) {
    if (options.item.alias === 'tamarind pod') return falsemsg('Mandy wonders if burying the tamarind pod is going to achieve anything. She has a feeling she really needs to get the seeds out first.')
    if (options.item.name !== 'tamarind_seed') return falsemsg('Mandy wonders if burying {nm:item:the} is going to achieve anything. Probably not.', {item:options.item})
    if (w.hourglass.active) return falsemsg('Mandy starts to put another {nm:item:} in the ground, but as her hands get near, they start to blur, and feel numb. Perhaps not such a good idea when the hourglass is running.', {item:options.item, item_count:options.count})
    return true
  },
  testTakeOut:function(options) {
    if (w.hourglass.active) return falsemsg('Mandy starts to dig {nm:item:} from the ground, but as her hands get near, they start to blur, and feel numb. Perhaps not such a good idea when the hourglass is running.', {item:options.item, item_count:options.count})
    return true
  },
})

createItem("grown_tamarind_tree", {
  isLocatedAt:function(loc) { return loc === 'greenhouse_west' && this.seedsPlanted > 0 && this.growthTime > 0 },
  seedsPlanted:0,
  growthTime:0,
  synonyms:['tamarind plants', 'tamarind seedlings', 'tamarind trees'],
  saveLoadExcludedAtts:['growDescs', 'examineDescs'],
  parserPriority:50,
  examine:function() {
    let s = "Mandy can see {nm:item:count:false:count_this}."
    if (this.seedsPlanted > 5) {
      if (this.growthTime > 8) {
        s += ' The trees have become tangled together, and look a like freaky mutants to Mandy.'
      }
      else if (this.growthTime > 5) {
        s += ' The plants are entwined around each other.'
      }
    }
    msg(s, {item:w.grown_tamarind_tree, count_this:'seedsPlanted'}) 
  },
  countable:true,
  getDescId:function() {
    let n = this.seedsPlanted - 1
    if (this.seedsPlanted > 3) n = 2
    if (this.seedsPlanted > 5) n = 3
    return 4 * this.growthTime + n - 4
  },
  getHeight:function() {
    const n = Number(Math.pow(2, this.growthTime/1.3).toPrecision(1))
    let s = n >= 100 ? lang.toWords(n / 100) + ' metre' : lang.toWords(n) + ' centimetre'
    if (n !== 1 && n !== 100) s += 's'
    return s
  },
  afterLoad:function() {
    this.update()
  },
  update:function() {
    this.pronouns = this.seedsPlanted === 1 ? lang.pronouns.thirdperson  : lang.pronouns.plural
    let alias = this.growthTime < 4 ? 'shoot' : (this.growthTime < 9 ? 'plant' : 'tree')
    this.setAlias(alias)
  },
  magicGrowth:function() {
    if (this.seedsPlanted === 0) return
    this.growthTime++
    this.update()
    msg("Mandy watches as {nv:item:grow:false:count_this}; {nv:item:be:false:suppressCount} now about {show:grown_tamarind_tree:getHeight} high.", {item:w.grown_tamarind_tree, count_this:'seedsPlanted', suppressCount:'seedsPlanted'})
  },
  magicGrowthEnd:function() {
    if (this.seedsPlanted === 0) return
    msg("{nv:item:wither:true} away to nothing.", {item:w.grown_tamarind_tree})
    this.seedsPlanted = 0
    this.growthTime = 0
  },
  climbverb:function(options) {
    return currentLocation.up.use(options.char)
  },
})





createRoom("up_a_tree", {
  alias:'a tamarind tree',
  headingAlias:'Up A Tamarind Tree',
  properNoun:true,
  noFollow:true,
  windowsface:'none',
  desc:"Mandy is up a tamarind tree. She is almost up as high as the catwalk... And well short of the top of the metal box.",
  down:new Exit("greenhouse_west", {msg:'Mandy carefully climbs back down.'}),
})




createRoom("up_a_tall_tree", {
  alias:'a tall tamarind tree',
  headingAlias:'Up A Tall Tamarind Tree',
  properNoun:true,
  noFollow:true,
  windowsface:'none',
  desc:"Mandy is up a tall tamarind tree. She is higher than the catwalk, to the north, and could probably reach the top of the metal box to the southwest.",
  down:new Exit("greenhouse_west", {msg:'Mandy carefully climbs back down, dropping the last couple of metres to the ground.'}),
  north:new Exit("greenhouse_catwalk_west", {msg:'Mandy gingers edges along a stout branch. It starts to drop alarmingly, but she manages to grab the catwalk, and scramble onto the walkway.'}),
  southwest:new Exit("lift", {
    msg:'Mandy looks at the top of the metal box.. She can do this. She edges along a sturdy looking branch, and reaches out, triumphantly grabbing a metal bar that runs across the top of the box. The branch starts to sag alarmingly, and she quickly hauls herself onto the platform.',
    simpleUse:function(char) {
      if (w.lift.getTransitDestLocation() !== w.steam_control_room) return falsemsg("Mandy looks at the top of the metal box, and realises the lift is not there. It would be a bad idea heading that way, she decides.")
      return util.defaultSimpleExitUse(char, this)
    },
  }),
})




createRoom("greenhouse_catwalk_west", {
  alias:'west end of the greenhouse catwalk',
  todo:'Room description needs work.',
  headingAlias:'The Greenhouse (West, On Catwalk)',
  windowsface:'none',
  desc:"{floraDesc}She is standing on a catwalk, suspended from the ceiling by metal rods. From here she can reach out and touch the leaves of the trees, and look down on the beautiful red flowers below. The catwalk continues to the east; the only other direction is the door to the west.{floraFlowerBed:true} Against the west wall, there is a huge metal box, with some kind of framework above it.",
  west:new Exit("upper_steam_hall"),
  east:new Exit("greenhouse_catwalk_east"),
  southwest:new Exit("up_a_tall_tree", {
    isHidden() { return (w.grown_tamarind_tree.growthTime < 9) },
    msg:"Mandy looks at the tall tamarind tree. {once:From below it looked like the catwalk was close. Now... not so much. She climbs over the balustrade, and looks down. 'Shit.' It is a long way to fall. She takes a moment to calm her nerves, then reaches across, grabbing a branch she hopes will be strong enough. She pulls it closer, and then grabs it with her other hand. She shrieks as the branch sags under her weight, but it does not break, and she can climb up, into the relative safety of the heart of the tree.:Wondering why she is risking her life doing this again, Mandy climbs over the balustrade, then reaches across, grabbing a branch she hopes will be strong enough. She pulls it closer, then closes her eyes as she grabs with the other hand, and for a moment is falling as the branch sags under her weight. She quickly climbs up into the heart of the tree.}",
  }),
  scenery:[
    { alias:['poppies', 'poppy'], examine:'Down below, there is a large flower bed with poppies growing.' },
    { alias:'marigolds', examine:'From this high up, the marigolds just looks like a sea of red. A very small sea, she thinks to herself.' },
    { alias:['chrysanthemums', 'carnations'], examine:'The chrysanthemums, or perhaps carnations, look beautiful.' },
    { alias:'bottlebush tree', examine:'From this vantage point, Mandy can see the blossoms in detail, and appreciate why it is so called.' },
    { alias:'tamarind pod', examine:'The pods are pale brown, knobbly and about as long as her hand.' },
  ],
})




createRoom("greenhouse_east", {
  alias:'east end of the green house',
  todo:'Room description needs work.',
  headingAlias:'The Greenhouse (East)',
  windowsface:'north',
  desc:"{floraDesc}Ma.",
  west:new Exit("greenhouse_west"),
  east:new Exit("great_hall"),
  afterEnterIf:[
    {
      test:function() { return w.greenhouse_east.visited === 3 },
      action:function() {
        msg("Mandy sees movement up on the catwalk. A silver figure, running round it, and then down the section to the west, before disappearing from view.")
        player.silverSpotted++
      },
    },
  ],
  climb:new Exit("_", {
    alsoDir:['up'],
    simpleUse:function(char) {
      log(char)
      if (char === w.Patch) {
        if (w.Patch.huggingTree) return falsemsg("'Climb the stupid tree,' says Mandy. Patch looks forlornly up the tree he is hugging.")
        msg("'Climb the tree, Patch,' says Mandy. Patch eyes up the tamarind tree , then steps closer, putting both arms round it. He pauses, and looks up, then down again, then up again. Apparently, climbing is not his thing.")
        w.Patch.huggingTree = true
        return true
      }
      
      if (w.Patch.isHere() && w.Patch.huggingTree) {
        msg("Mandy appraises the tree, with Patch still hugging it. She could use Patch to get up it. 'Er, just, hold still,' she tells him, as she grabs his solid arm, and starts to haul herself up. 'And keep looking downwards!' She pulls herself up onto his shoulder, and from there she grabs a lower branch, and hauls herself up.")
        player.moveChar(new Exit('up_a_tall_tree_east', this))
        return true
      }
      return falsemsg("Mandy looks up at the tamarind tree; it is too tall to climb. The lowest branches are way out of reach.")
    },
  }),
})

createItem("tamarind_tree_from_ground", {
  loc:"greenhouse_east",
  scenery:true,
  parserPriority:-20,
  examine:"The tamarind tree is tall, its thick truck rises almost twice Mandy's height before branches spread out.",
  climbverb:function(options) {
    return currentLocation.up.use(options.char)
  },
  shake:'Mandy tries to shake the tree, but the trunk is too thick; it does not budge. If only she were higher up...',
  take:'The tree is far too heavy for Mandy to pick up, and would probably be rather awkward to carry.',
})



createRoom("up_a_tall_tree_east", {
  alias:'a tamarind tree',
  headingAlias:'Up A Tamarind Tree',
  properNoun:true,
  windowsface:'none',
  desc:"Mandy is up a tamarind tree, up higher than the catwalk, hopefully in easy reach of a tamarind pod.",
  down:new Exit("greenhouse_west", {msg:'Mandy carefully climbs back down.'}),
  noFollow:true,
})
createItem("tamarind_pod_up_tree", {
  loc:'up_a_tall_tree_east',
  alias:'tamarind pod',
  scenery:true,
  examine:'The pods are pale brown, knobbly and about as long as her hand.',
  take:function() {
    msg("Mandy reaches out, and grabs a pod.")
    cloneObject(w.tamarind_pod_prototype, player.name)
    return true
  },
})


createRoom("greenhouse_catwalk_east", {
  alias:'east end of the greenhouse catwalk',
  todo:'Room description needs work.',
  headingAlias:'The Greenhouse (East, On Catwalk)',
  windowsface:'north',
  desc:"{floraDesc}She is standing on a catwalk that skirts the north side of the great greenhouse. Even from here, the huge oak tree towers over her.",
  west:new Exit("greenhouse_catwalk_west"),
  east:new Exit("great_gallery"),
  afterFirstEnter:function() {
    msg("Is there someone down below? He - or she for all Mandy can tell - is wearing a silver shell-suit like it is 1996 or something. 'Hey!' calls Mandy. The figure looks up for a moment, and Mandy can see his face is silver too, before darting off to the east.")
    player.silverSpotted++
  },
})

createItem("tamarind_tree", {
  loc:"greenhouse_catwalk_east",
  scenery:true,
  parserPriority:-20,
  examine:"The single tamarind tree is a big one, reaching almost to roof of the great greenhouse. From here, Mandy could reach out and touch the leaves of the tree, though the many seed pods are further away.",
  take:function() {
    msg("Mandy leans over the rail, and grabs a solid-looking leaf on the tamarind tree. She gives it a good tug, then another and another, until a ripe pod is dislodged. The pod falls...")
    if (w.Patch.loc === 'greenhouse_east' && w.Patch.hasPod) return falsemsg("Patch looks very confused as he stares at the pod in his hand, then the pod on the ground, then the pod in his hand again. Then suddenly a silvery figure appears from the west, quickly scoops up the pod from the floor, and runs back west.")
    if (w.Patch.loc !== 'greenhouse_east') return falsemsg("Suddenly a silvery figure appears from the west, quickly scoops up the pod from the floor, and runs back west.{once: 'Shit,' mutters Mandy.}")
      
    msg("... To be caught with surprising dexterity by {nm:npc:the}, who is standing below.", {npc:w.Patch})
    cloneObject(w.tamarind_pod_prototype, 'Patch')
    w.Patch.hasPod = true
    return true
  },
  shake:function(options) { this.take(options) },
})

createItem("tamarind_pod_on_tree", {
  locList:['greenhouse_catwalk_east', 'greenhouse_east'],
  isLocatedAt:function(room_name) { return this.locList.includes(room_name) },
  alias:'tamarind pod',
  scenery:true,
  parserPriority:-10,
  examine:'The pods are pale brown, knobbly and about as long as her hand. And out of reach.',
  take:'The tamarind pods are out of reach.',
})

createItem("tamarind_pod_prototype", SIZE_CHANGING(), {
  alias:'tamarind pod',
  openable:true,
  desc5:'The pod is pale brown, knobbly and about as long as her hand.',
  desc4:"The pod is tiny.",
  desc6:'The pod is pale brown, knobbly and about as long as her arm.',
  open:function(options) {
    if (w.glass_shard.loc !== player.name) msg('Mandy tries to open the tamarind pod, but it is too tough for her fingernails. She needs something a little sharper.')
    const count = random.int(3, 5)
    msg("Using the shard of glass, Mandy cuts the pod open. Inside she finds " + lang.toWords(count) + " seeds, which she quickly extracts, throwing away the useless husk.")
    if (!w.tamarind_seed.countableLocs[player.name]) w.tamarind_seed.countableLocs[player.name] = 0
    w.tamarind_seed.countableLocs[player.name] += count
    delete this.loc
    return true
  },
})

createItem("tamarind_seed", COUNTABLE(), {
  regex:/^(\d+ )?seeds?$/,
  defaultToAll:false,
  examine:'The tamarind seed is black and shiny; more like a pebble than a seed.',
  testDrop:function(options) { 
    if (options.container) return true
    return falsemsg('Mandy decides it is best not to drop any seeds here - they might grow into a tree!') 
  },
  msgDropIn:"{ifNot:container:name:bare_earth:" + lang.drop_successful + ":Mandy carefully plants {nm:item:count} in the bare earth.}",
})



