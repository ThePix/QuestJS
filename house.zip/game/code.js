"use strict"


const profanity = "~ç$|²\u0018­|¦+,|u©§|réí|·\u0006­|v'$|Á©ä|r\u0087$|az·îrG«";
let swearJar = {
  counter:0,
  list:[]
};

function profanityChecker(data){
  let rgx = profanity;
  rgx = "\\b(?:" + rgx.split("|").map(rgx => btoa(rgx)).join("|") + ")";
  log(rgx)
  rgx = new RegExp(rgx, "gi");
  if (rgx.exec(data)){
    //console.log("Profanity!")
    swearJar.counter++;
    swearJar.list.push(data)
    return true;
  }
  return false;
}

// Data taken from here: https://www.gamehouse.com/blog/leet-speak-cheat-sheet/
const leet = {
  a:["4", "/\\", "@", "/-\\", "^", "aye", "(L", "Д"],
  b:["I3", "8", "13", "|3", "ß", "!3", "(3", "/3", ")3", "|-]", "j3", "6"],
  c:["[", "¢", "{", "<", "(", "©"],
  d:[")", "|)", "(|", "[)", "I>", "|>", "?", "T)", "I7", "cl", "|}", ">", "|]"],
  e:["3", "&", "£", "€", "ë", "[-", "|=-"],
  f:["|=", "ƒ", "|#", "ph", "/=", "v"],
  g:["&", "6", "(_+", "9", "C-", "gee", "(?,", "[,", "{,", "<-", "(.", ""],
  h:["#", "/-/", "[-]", "]-[", ")-(", "(-)", ":-:[", "|~|", "|-|", "]~[", "}{", "!-!", "1-1", "\-/", "I+I", "/-\I", "1", "[]"],
  i:["1", "[]", "|", "!", "eye", "3y3", "]["],
  j:[",_|", "_|", "._|", "._]", "_]", ",_]", "]", ";", "1"],
  k:[">|", "|<", "/<", "1<", "|c", "|(", "|{"],
  l:["1", "£", "7", "|_", "|"],
  m:["/\\/\\", "/V\\", "JVI", "[V]", "[]V[]", "|\/|", "^^", "<\\/>", "{V}", "(v)", "(V)", "|V|", "nn", "IVI", "|\\|\\", "]\\/[", "1^1", "ITI", "JTI"],
  n:["^/", "|\\|", "/\\/", "[\\]", "<\\>", "{\\}", "|V", "/V", "И", "^", "ท"],
  o:["0", "Q", "()", "oh", "[]", "p", "<>", "Ø"],
  p:["|*", "|o", "|º", "?", "|^", "|>", "|\"", "9", "[]D", "|°", "|7"],
  q:["(_,)", "9", "()_", "2", "0_", "<|", "&"],
  r:["I2", "|`", "|~", "|?", "/2", "|^", "lz", "|9", "2", "12", "®", "[z", "Я", ".-", "|2", "|-"],
  s:["5", "$", "z", "§", "ehs", "es", "2"],
  t:["7", "+", "-|-", "']['", "†", ""|"", "~|~"],
  u:["(_)", "|_|", "v", "L|", "µ", "บ"],
  v:["\\/", "|/", "\\|"],
  w:["\\/\\/", "VV", "\\N", "'//", "\\\\'", "\\^/", "(n)", "\\V/", "\\X/", "\\|/", "\\_|_/", "\\_:_/", "Ш", "Щ", "uu", "2u", "\\\\//\\\\//", "พ", "v²"],
  x:["><", "Ж", "}{", "ecks", "×", "?", ")(", "]["],
  y:["j", "`/", "Ч", "7", "\\|/", "¥", "\\//"],
  z:["2", "7_", "-/_", "%", ">_", "s", "~/_", "-\\_", "-|_"],
}

const walkthroughs = {
  telescope:[
    "x t", "x ceiling", "u", "n", "w", "d",
    "push lever",
    "x t", "x ceiling", "u", "n", "w", "d",
    "push lever",
    "turn left left", "turn left left", "turn left left",
    "x t", "x ceiling", "u", "x ceiling", "n", "w", "d",
    "push lever",
    "x t", "x ceiling", "u", "n", "w", "d",
    "push lever",
    "turn right left", "turn right left", "turn right left", "turn right left", "turn right left",
    "x t", "x ceiling", "u", "x ceiling", "n", "w", "d",
    "push lever",
    "x t", "x ceiling", "u", "x ceiling", "n", "w",
  ],
  a:[
    "open bag",
    "x book",
    "x Antony",
    "x Antony and Cleopatra",
    "x book",
    "x book",
    "x othello",
    "x Antony",
    "north",
    "south",
    "east",
    "knock on door",
    "knock on door",
    "look through door",
    "e",
    "w",
    "get letter",
    "drop letter",
    "read letter",
    "open letter",
    "put letter in bag",
    "e",
    "x door",
    "look through door",
    "e",
    "s",
    "n",
    "s",
    "n",
    "x fireplace",
    "x clock",
    "x key",
    "get key",
    "south",
    "x win",
    "south",
    "x window",
    "smash window",
    "n",
    "smash window",
    "l",
    "get shard",
    "x window",
    "east",
    "northeast",
    "x cab",
    "x cracks",
    "north",
    "southwest",
    "west",
    "south",
    "east",
    "x cab",
    "x win",
    "shift cab",
    "west",
    "north",
    "east",
    "northeast",
    "x cab",
    "x cracks",
    "north",
    "get boots",
    "s",
    "southwest",
    "drop boots",
    "west",
    "south",
    "east",
    "get boots",
    "west",
    "north",
    "south",
    "south",
    "east",
    "east",
    "east",
    "x boots",
    "north",
    "ask man about house",
    "open dolls",
    "x doll",
    "x man",
    "get balloon",
    "talk to man",
    "ask man about boots",
    "ask man about shoes",
    "give boots to man",
    "ask man about boots",
    "get balloon",
    "give boots to man",
    "Wait",
    "get balloon",
    "get boots",
    "x boots",
    "s",
  ],
}






findCmd('MetaHint').script = function() {
  metamsg("Hints can be found on {link:this page:https://github.com/ThePix/QuestJS/wiki/Hints-for-The-House-on-Highfield-Lane}, in the form of InvisiClues, so you can avoid seeing spoilers you do want to see. The page will open in a new tab, so will not affect your playing of the game.")
  return world.SUCCESS_NO_TURNSCRIPTS
},


findCmd('MetaHelp').script = function() {
  metamsg("Enter commands to navigate the world. Use the compass directions, plus UP, DOWN, IN, OUT to move around. Use commands like GET LETTER and DROP PEN to pick things up and drop them. Use INVENTORY (or just I) to see what you are carrying. For more details go to {link:this page:https://github.com/ThePix/QuestJS/wiki/How-To-Play}, which will open in a new tab.")
  return world.SUCCESS_NO_TURNSCRIPTS
},




lang.exit_list.push({name:'climb', alt:'climb up', abbrev:'Cl', niceDir:"above", type:'vertical', x:0 ,y:0, z:1, opp:'down', not_that_way:'Nothing to climb here.'},)
lang.exit_list.push({name:'climb_down', alt:'climb down', abbrev:'CD', niceDir:"below", type:'vertical', x:0 ,y:0, z:-1, opp:'climb', not_that_way:'Nothing to climb down here.'},)



parser.itemSetup = function(item) {
  item.parserOptionsSet = true
  item.parserItemName = item.alias.toLowerCase().replace(/[^\w ]/g, '')
  item.parserItemNameParts = array.combos(item.parserItemName.split(' '))
  if (item.pattern) {
    if (!item.regex) item.regex = new RegExp("^(" + item.pattern + ")$") 
    if (!item.synonyms) item.synonyms = item.pattern.split('|')
  }

  let list = [item.alias.toLowerCase().replace(/[^\w ]/g, '')]
  if (item.synonyms) {
    for (const el of item.synonyms) {
      const s = el.toLowerCase().replace(/[^\w ]/g, '')
      list.push(s)
      list = list.concat(array.combos(s.split(' ')))
    }
    item.parserItemNameParts = item.parserItemNameParts.concat([...new Set(list)])
    array.remove(item.parserItemNameParts, 'and')
    array.remove(item.parserItemNameParts, 'of')
  }
}

parser.specialText.integer = {
  error:function(text) {
    return false
  },
  exec:function(text) {
    return parseInt(text)
  },
}





//  ----------- SUPPORT FOR ZONES ---------------------------

const zones = {}
let zone

const register = function(name, data) {
  w.uniform.uniforms[name] = data.uniform
  w.shakespeare_book.names[name] = data.book
  zones[name] = data
  zone = name
}




//  ----------- SUPPORT FOR SIZE-CHANGING ---------------------------

// Default to five; original defaulted to zero

const sizes = {
  1:'xxsmall',
  2:'xsmall',
  3:'vsmall',
  4:'small',
  5:'int',
  6:'big',
  7:'vbig',
  8:'xbig',
  9:'xxbig',
}
const sizeAdjectives = {
  1:'too-tiny-to-see',
  2:'minute',
  3:'tiny',
  4:'small',
  5:'',
  6:'big',
  7:'huge',
  8:'enormous',
  9:'gargantuan',
}



const SIZE_CHANGING = function() {
  const res = $.extend({}, TAKEABLE_DICTIONARY)
  res.size_changing = true
  res.size = 5
  res.minsize = 3
  res.maxsize = 6
  
  res.afterCreation = function(o) {
    o.basealias = o.alias
    if (!o.desc4) log("WARNING: Size changer " + o.name + " has no desc4.")
    if (!o.desc5) log("WARNING: Size changer " + o.name + " has no desc5.")
    //if (!o.desc6) log("WARNING: Size changer " + o.name + " has no desc6.")
    if (o.desc3) o.minsize = 2
    if (o.desc2) o.minsize = 1
    if (o.desc1) o.minsize = 0
    if (o.desc6) o.maxsize = 7
    if (o.desc7) o.maxsize = 8
    if (o.desc8) o.maxsize = 9
    if (o.desc9) o.maxsize = 10
  }
  
  res.examine = function(options) {
    if (this.size === this.minsize) {
      msg("{nv:item:be:true} too tiny to see properly!", {item:this})
    }
    else if (this.size === this.maxsize) {
      msg("{nv:item:be:true} of gigantic proportions!", {item:this})
    }
    else {
      msg(this['desc' + this.size])
    }
    return true
  }

  res.take = function(options) {
    if (this.isAtLoc(options.char.name)) {
      return falsemsg(lang.already_have, options)
    }
    if (!options.char.canManipulate(this, "take")) return false
    
    if (this.size === this.maxsize) {
      return falsemsg("{nv:item:be:true} far too big to pick up.", {item:this})
    }
    else if (this.size === this.minsize) {
      return falsemsg("Mandy tries to pick up {nm:item:the}, but {pv:item:be} too tiny for her fingers to grasp.", {item:this})
    }    
    
    msg(this.msgTake, options)
    this.moveToFrom(options, "name", "loc")
    if (this.scenery) this.scenery = false
    return true
  }

  res.shrink = function() {
    this.size--
    this.setAlias(this.size === 5 ? this.basealias : sizeAdjectives[this.size] + ' ' + this.basealias)
  }

  res.grow = function() {
    this.size++
    this.setAlias(this.size === 5 ? this.basealias : sizeAdjectives[this.size] + ' ' + this.basealias)
  }
    
  return res;
}














//  ----------- COMMANDS ---------------------------



commands.unshift(new Cmd('KnockOn', {
  regex:/^(?:knock on|knock|rap|rap on|tap|tap on) (.+)$/,
  objects:[
    {scope:parser.isHere},
  ],
  defmsg:"{pv:item:'be:true} not something you can knock on.",
}))

commands.unshift(new Cmd('StareAt', {
  regex:/^(?:stare at|stare) (.+)$/,
  objects:[
    {scope:parser.isHere},
  ],
  defmsg:"Mandy stares at {nm:item:the} for a few minutes, not sure quite what she expects it to do.",
}))

commands.unshift(new Cmd('Shake', {
  regex:/^(?:shake) (.+)$/,
  objects:[
    {scope:parser.isHere},
  ],
  defmsg:"Shaking {nm:item:the} is not going to achieve anything.",
}))

commands.unshift(new Cmd('WindUp', {
  regex:/^(?:wind up|wind) (.+)$/,
  objects:[
    {scope:parser.isHere},
  ],
  defmsg:"{pv:item:'be:true} not something you can wind up.",
}))

commands.unshift(new Cmd('Plant', {
  regexes:[
    /^(?:plant|bury) (.+)$/,
    /^(?:plant|bury) (.+) in (?:earth|ground|soil|bare earth|bare ground)$/,
  ],
  objects:[
    {scope:parser.isHeld},
  ],
  script:function(objects) {
    const obj = objects[0][0]
    if (objects[0][0] !== w.tamarind_seed) return falsemsg("{pv:item:'be:true} not something Mandy really wants to bury.", {item:item})
      objects.push([w.bare_earth])
    return handleInOutContainer(player, objects, "drop", handleSingleDropInContainer)
  },
}))

commands.unshift(new Cmd('ClimbVerb', {
  regex:/^(?:climb up|climb|go up|ascend) (.+)$/,
  npcCmd:true,
  objects:[
    {scope:parser.isHere},
  ],
  defmsg:"{pv:item:'be:true} not something you can climb.",
}))

commands.unshift(new Cmd('ClimbDownVerb', {
  regex:/^(?:climb down|go down|descend) (.+)$/,
  npcCmd:true,
  objects:[
    {scope:parser.isHere},
  ],
  defmsg:"{pv:item:'be:true} not something you can climb.",
}))

commands.unshift(new Cmd('Shift', {
  regex:/^(?:shift|move) (.+)$/,
  objects:[
    {scope:parser.isHere},
  ],
  script:function(objects) {
    const obj = objects[0][0]
    const tpParams = {item:obj}
    
    if (!obj.shiftable && obj.takeable) return failedmsg(lang.take_not_push, tpParams)
    if (!obj.shiftable) return failedmsg(lang.cannot_push, tpParams)

    return obj.shift() ? world.SUCCESS : world. FAILED
  },
}))

commands.unshift(new Cmd('Invert', {
  regexes:[
    /^(?:invert|turn over) (.+)$/,
    /^turn (.+) over$/,
  ],    
  objects:[
    {scope:parser.isPresent, attName:'turn'},
  ],
  script:function(objects) {
    const obj = objects[0][0]
    if (!obj.turn) return failedmsg("Mandy thinks about turning {nm:item:the} upside-down, but decides it is fine the way it is.", {item:obj})
    return obj.turn() ? world.SUCCESS : world. FAILED
  },
}))

commands.unshift(new Cmd('BurstBalloon', {
  rules:[cmdRules.isHeld],
  regexes:[
    /^use (.+) to (?:burst|break|cut|puncture|pierce) (.+)$/,
    { regex:/(?:burst|break|cut|puncture|pierce) (.+) (?:with|using) (.+)/, mod:{reverse:true}},
  ],
  objects:[
    {scope:parser.isHeld},
    {scope:parser.isHere},
  ],
  script:function(objects) {
    if (objects[0][0] !== w.glass_shard) return failedmsg("Mandy's not going to pierce anything with that!")
    if (objects[1][0].name.startsWith('tamarind_pod_prototype')) return objects[1][0].open(false, player)
    // any other objects that are cuttable???
    if (objects[1][0] === w.yellow_balloon) return w.yellow_balloon.burst()
    
    return failedmsg("Mandy takes a few stabs at {nm:item:the} with the shard of glass, but does not acheive anything", {item:objects[1][0]})
  },
}))

findCmd('Smell').script = function() {
  if (currentLocation.smell) {
    printOrRun(player, currentLocation, "smell");
  }
  else {
    msg(zones[currentLocation.zone].smell)
  }
  return world.SUCCESS;
}

findCmd('Listen').script = function() {
  if (currentLocation.listen) {
    printOrRun(player, currentLocation, "listen");
  }
  else {
    msg(zones[currentLocation.zone].listen)
  }
  return world.SUCCESS;
}

findCmd('Say').script = function(objects) {
  const text = objects[1]
  if (currentLocation.name === 'nursery') {
    if (text.match(/hello|hi/)) {
      msg("Mandy says '" + text + ".'|'Alright?' says the tiny man in reply. She wonders if she should ask the man about something if she wants to get anywhere.")
    }
    else {
      msg("Mandy says '" + text + ".' The tiny man looks at her in confusion. She wonders if she should ask the man about something if she wants to get anywhere.")
    }
    return world.FAILED
  }
  if (w.Patch.loc === player.loc) {
    if (text.match(/hello|hi/)) {
      msg("Mandy says '" + text + ".' {nv:npc:nod:true} at her. Clearly he is not much of a conversationalist; she might do better to tell him to do something useful.", {npc:w.Patch})
    }
    else {
      msg("Mandy says '" + text + ".' {nv:npc:look:true} at her in confusion. Clearly he is not much of a conversationalist; she might do better to tell him to do something useful.", {npc:w.Patch})
    }
    return world.FAILED
  }
  if (currentLocation.name === 'steam_control_room') {
    if (text.match(/hello|hi/)) {
      msg("Mandy says '" + text + ".'|'Hello to you, miss' says Dr Malewicz. She wonders if she should ask him about something if she wants to get anywhere.")
    }
    else {
      msg("Mandy says '" + text + ".'|'I'm not sure I follow,' says Dr Malewicz. She wonders if she should ask him about something if she wants to get anywhere.")
    }
    return world.FAILED
  }
  if (currentLocation.name === 'weird_room') {
    if (text.match(/\b(one|1|1d)\b/)) {
      if (w.Winfield_Malewicz.songlist.length === 0) {
        msg("Mandy thinks about what makes her special. Then looks at her bag. Her {i:One Direction} bag. 'One Direction?' she says, tentatively.")
      }
      else {
        let s = "Mandy thinks about what makes her special. Then looks at her bag. Her {i:One Direction} bag. And then there were some of the things Dr Malewicz had said, like "
        s += formatList(w.Winfield_Malewicz.songlist.map(el => "{i:" + el + "}"), {lastJoiner:'and'})
        s += ". Had he been channelling the answer in some way?|'One Direction?' she says, tentatively."
        msg(s)
      }
      msg("The scornful face of the man-house darkens in anger for a moment, before he collapsed before her eyes in a shower of tiny bricks. For a moment nothing happens, but then the bricks start swirling around, rebuilding the figure. 'Oh, God, not again,' mutters Mandy. But the man-house thing looks different. He is no longer laughing at her.")
      msg("'Thank you,' he says, even as he slowly fades away. 'You saved me. I must apologise for my earlier behaviour, I was not quite myself.'")
      msg("'What..?' says Mandy, feeling utterly bewildered...")
      w.Winfield_Malewicz.loc = 'lounge'
      player.loc = 'lounge'
      world.update()
      world.enterRoom()
      return world.SUCCESS
    }
    if (text.match(/north|south|east|west/)) {
      msg("Mandy says '" + text + ".'|'Wrong!' says the house, gleefully.")
      if (w.Winfield_Malewicz.compassTried) {
        msg("'You think I somehow forgot that one?' says Dr Malewicz testily.")
      }
      else if (w.Winfield_Malewicz.nonCompassTried) {
        msg("'Yes, and I've tried all the compass directions too,' says Dr Malewicz.")
      }
      else {
        msg("'Yes, yes, I've tried all the compass directions,' says Dr Malewicz. 'It's nothing as obvious as that I'm afraid.'")
      }
      w.Winfield_Malewicz.compassTried = true
    }
    else if (text.match(/in|out|up|down|exit|enter/)) {
      msg("Mandy says '" + text + ".'|'Wrong!' says the house, gleefully.")
      if (w.Winfield_Malewicz.nonCompassTried) {
        msg("'You think I somehow forgot that one?' says Dr Malewicz testily.")
      }
      else if (w.Winfield_Malewicz.compassTried) {
        msg("'Yes, and I've tried all the non-compass directions too,' says Dr Malewicz.")
      }
      else {
        msg("'Yes, yes, I've tried all the up-and-down, and in-and-out directions,' says Dr Malewicz. 'It's nothing as obvious as that I'm afraid.'")
      }
      w.Winfield_Malewicz.nonCompassTried = true
    }
    else {
      msg("Mandy says '" + text + ".'|'Wrong!' says the house, gleefully.|'I'm not sure I follow your reasoning,' says Dr Malewicz. 'Is that a direction?'")
    }
    return world.SUCCESS
  }
 
  msg("Mandy says '" + text + "' out loud, then wonders why she is talking to herself.")
  return world.FAILED
}

