"use strict"

/*
The biggest zone?

*/


register('victorian', {
  book:'Othello',
  uniform:'a rather dowdy grey school uniform that makes her look about fifty',
  smell:'There is a faint musty smell, with just a hint of polish.',
  listen:'Mandy listens, but can hear nothing. It is eerily quiet...',
  floor:"The floor is wooden, and well-polished.",
  walls:"The walls are all panelled in wood.",
  ceiling:"The ceiling is white, with simple decorations along each side.",
})



createRoom("front_hall", {
  alias:"hall",
  windowsface:'west',
  exitState:0,
  desc:function() {
    return "The hall is bigger than Mandy expected, quite an impressive room really. There are doors to the north and south, while the east wall is adorned with a number of paintings. The walls and ceiling are panelled with dark wood, the floor is tiled in a {if:front_hall_floor:state:2:simple back and white check:geometric design that is vaguely unnerving}."
  },
  afterFirstEnter:function() {
    msg("The door slams shut, making Mandy jump.")
  },
  west:new Exit("_", {use:util.cannotUse, msg:'Mandy tries to go back outside, but that way is now mysteriously locked. It looks like she will have to head further into the house. It is strange, but now she is trapped inside the house, she does not feel so scared.'}),
  north:new Exit("brass_dining_room", {use:function(char) {
    if (w.front_hall.exitState < 2) w.front_hall.exitState = 1
    return util.defaultExitUse(char, this)
  }}),
  south:new Exit("gallery", {use:function(char) {
    if (w.front_hall.exitState < 2) w.front_hall.exitState = 2
    return util.defaultExitUse(char, this)
  }}),
  scenery:[
    {
      alias:['portraits', 'pictures', 'paintings'],
      examine:"There are five paints on the back wall, all portraits. To the left, an elderly gentleman, a little plump, in military attire. Next to him, a lady in a blue dress. The central portrait is a youngish man in academic mortar and gown. Next to him, another lady, perhaps in her thirties, and on the far right, a rather dapper young man in a burgundy suit."
    },
  ],
})

createItem("inside_door", {
  loc:"front_hall",
  alias:'door',
  scenery:true,
  examine:"Mandy tried the door; it is definitely locked shut.",
  open:"Mandy tried the door; it is definitely locked shut.",
})




createItem("front_hall_floor", {
  loc:"front_hall",
  alias:'floor',
  synonyms:['image', 'design'],
  scenery:true,
  state:0,
  examine:function() {
    if (this.state === 0) {
      msg("The design on the floor is like one of those pictures her father likes; if you stare at them in just the right way a three-dimensional image emerges. Mandy is not sure why, but she really does not want to see that image in the floor. She shudders involuntarily.")
    }
    else if (this.state === 1) {
      msg("Mandy gingerly looks at the design on the floor again... It has gone! It is just a simple black and white check. How can that be?")
      this.state = 2
    }
    else {
      msg("The floor is tiled, a simple black and white check design.")
    }
  },
  stareat:function() {
    if (this.state === 0) {
      msg("'Pull yourself together,' Mandy says to herself 'It's just a floor, for Christ's sake.' She stares at it, but nothing happens. She tries slowly walking round the peculiar design, whilst staring at it, but nothing.|Wait, her father always says to stare {i:beyond} it. She stands staring at an imaginary point about a meter below the floor...|Suddenly the image pops into view - a huge mouth, like a snake's or dragon's - wide open, and about to snap shut around her. She shrieks as she jumps back in shock, and as suddenly as it appears, the giant mouth disappears. As her pounding heart slows, she quickly looks round, thankful no one was around to witness that.")
      this.state = 1
    }
    else if (this.state === 1) {
      msg("Mandy gingerly looks at the design on the floor again... It has gone! It is just a simple black and white check. How can that be?")
      this.state = 2
    }
    else {
      msg("Mandy stares at the black and white checks on the floor, but nothing happens. Not even when she stares at an imaginary point about a meter below the floor.")
    }
  },
})





createRoom("brass_dining_room", {
  alias:"dining room",
  mannequin_count:4,
  windowsface:'north',
  blocked:function() {
    if (this.visited < 11) return false 
    if (w.large_key.loc === 'clock') return false
    for (const key in w) {
      if (w[key].loc === 'brass_dining_room' && !w[key].scenery) return false
    }
    return true
  },
  desc:function() {
    let s = "This room is dominated by an elegant, dark wood table, well-polished, with brass legs shaped like a lion's, and laid out with eight dinner settings. Eight chairs, in matching style, surrounded it. At the table, "
    msg (" ")
    if (this.visited < 5) {
      s += lang.toWords(this.visited + 4) + " mannequins are sat, dressed up in clothes and wigs."
    }
    else if (this.visited === 5) {
      s += "eight mannequins are sat, dressed up in clothes and wigs; a ninth is stands behind one of the chairs."
    }
    else {
      s += "eight mannequins are sat, dressed up in clothes and wigs; " + lang.toWords(this.visited - 4) + " more are stands as though waiting to take their place."
    }
    if (this.visited > 8) s += " It is getting crowded in here!"
    s += " The north wall has a window, with dark wood cabinets on either side, and there is a grand marble fireplace directly opposite the window, with a large clock on the mantelpiece. There are doors to the east, south and west. "
    return s
  },
  afterFirstEnter:function() {
    if (!w.front_hall.notedasweird) {
      msg("{i:That's weird}, Mandy thinks, {i:there should be a window in the west wall, looking towards the street. Where could the door possibly go?}")
      w.front_hall.notedasweird = true
    }
  },
  south:new Exit("gallery", {use:function(char) {
    if (w.front_hall.exitState === 1) {
      msg("Mandy walks south... {i:Wait, this isn't the hall,} she thinks to herself. She is positive this is the door way she came through before, so why is she not in the hall?")
      w.front_hall.exitState = 5
    }
    else {
      msg("Mandy heads south.")
    }
    char.moveChar(this)
    return true
  }}),
  west:new Exit("great_gallery"),
  east:new Exit("steam_corridor"),
  scenery:[
    {
      alias:['mantel','grate','mantelpiece','chimney piece',"fireplace"],
      examine:"The fireplace is of a classical style, with two columns either side that are very similar to the museum in the market square; Mandy can vaguely remember being told the museum is Victorian, so perhaps the fireplace is that old too. She cannot imagine it is actually from ancient Greece! There is a large, old-fashioned clock on the mantelpiece.",
    },
    {
      alias:'chairs',
      examine:"The chair is made of dark wood, with a high back and a padded seat.",
    },
    {
      alias:"table",
      examine:"The table tp is made of the same dark wood as the chairs. The legs are rather ornate, and shaped like the legs of a lion; the brass is not as clean as you might hope for a dining room table.",
    },
  ],
})

createItem("mannequins", {
  loc:"brass_dining_room",
  scenery:true,
  examine:"Mandy looks closer at the mannequins. Their skin is a speckled grey that feels cool to the touch, and sounds like wood when knocked. Their faces are only half formed; slight depression to suggest eyes, a vague nose, but no mouth. They are naked, but genderless.",
})

createItem("clock", CONTAINER(false), {
  loc:"brass_dining_room",
  scenery:true,
  alias:"clock",
  testDropIn(options) {
    if (options.item !== w.key) return falsemsg("That' not something you can put in a clock.")
    return true
  },
  examine:function() {
    let s = "This is a large, old-fashioned clock. A dark wood case houses the ticking mechanism. Roman numerals ran round the clock face, "
    if (typeof this.lookturn === "number") {
      if (this.lookturn > (game.turn - 10)) {
        s += "which indicate the time is now twenty past nine."
      }
      else {
        s += "which indicate the time is still twenty past nine. It is ticking, so has clearly not stopped; why is the time not changing?"
      }
    }
    else {
      s += "which indicate the time is now twenty past nine. That is so wrong, Mandy cannot decide if it is slow or fast."
      this.lookturn = game.turn
    }
    if (w.large_key.isAtLoc(this.name)) {
      s += " Mandy can see the key for winding the clock up is in the side of the clock."
    }
    msg(s)
  },
  windup:function() {
    if (w.large_key.loc === player.name) {
      return clock.dowindup()
    }
    else {
      return falsemsg("Mandy has nothing to wind the clock up with.")
    }
  },
  dowindup:function() {
    if (w.large_key.size < 5) {
      return falsemsg("Mandy looks at the hole in the back of the inanimate figure; a square peg. Like it would fit the key she has - only much much bigger.")
    }
    if (w.large_key.size > 5) {
      return falsemsg("Mandy looks at the hole in the back of the inanimate figure; a square peg. Like it would fit the key she has - if not {i:that} big.")
    }
    msg("Mandy puts the key in clock, and gives it a couple of turns. It continues to tick...")
    return true
  },
})

createItem("large_key", SIZE_CHANGING(), {
  loc:"clock",
  scenery:true,
  alias:"clock key",
  desc4:"The key is tiny.",
  desc5:"This key is about an inch across, and would be for turning a mechanism with a square peg.",
  desc6:"This key is about a foot across, and would be for turning a mechanism with a square peg. A big square peg.",
  desc7:"The key is huge.",
  use:function() {
    if (player.loc === 'theatre_stage') {
      w.clockwork_thespian.dowindup()
    }
    else if (player.loc === 'brass_dining_room') {
      w.clock.dowindup()
    }
    else {
      msg("Mandy wonders what she could use the clock key for. Besides winding up the clock, that is.")
    }
  },
})









createRoom("gallery", {
  windowsface:'west',
  alias:'north end of the gallery',
  headingAlias:"The Gallery (North)",
  desc:"Mandy is standing at the north end of a long and rather gloomy corridor - at least this end has a couple of windows, the southern end looks even darker. Doors lead north and east. A small table with a chess board set in it stands against the west wall, under the middle window. There are paintings on the east wall.{once: Why would anyone hang paintings where it is so dark?}",
  afterFirstEnter:function() {
    if (!w.front_hall.notedasweird) {
      msg (" ")
      msg("That's weird, thinks Mandy, surely the door to the west would go back into the garden? And this room is so long, surely the house is not this wide...")
      w.front_hall.notedasweird = true
    }
  },
  north:new Exit("brass_dining_room", {use:function(char) {
    if (w.brass_dining_room.blocked()) return falsemsg("Mandy starts heading north, but the dining room is now so full of mannequins, she cannot get into it.")
    if (w.front_hall.exitState === 2) {
      msg("Mandy walks north... {i:Wait, this isn't the hall,} she thinks to herself. She is positive this is the door way she came through before, so why is she not in the hall?")
      w.front_hall.exitState = 5
    }
    else {
      msg("Mandy heads north.")
    }
    char.moveChar(this)
    return true
  }}),
  south:new Exit("gallery_south", {msg:'Mandy heads to the other end of the gallery; the floor boards squeak under her feet.'}),
  east:new Exit("_", {simpleUse:function(char) {
    if (!w.room_big.accessedFrom) w.room_big.accessedFrom = 'gallery_south'
    const dest = w.room_big.accessedFrom === 'gallery' ? w.room_big : w.room_small
    return util.defaultSimpleExitUse(char, new Exit(dest, {origin:this.origin, dir:this.dir}))
  }}),
  scenery:[
    {
      alias:['portraits', 'pictures', 'paintings'],
      examine:"The paintings are all oil on canvas, and to Mandy's inexpert eye the same style, though they vary in subject matter. Several are portraits, but there is a Greek temple and a rather beautiful sunset. The biggest painting, opposite the chess set, is of a cavalry man in red uniform, astride a great white stallion, sabre in hand. All around him are infantry soldiers in blue - presumably the enemy.",
    },
    {
      alias:"chess set",
      examine:"The chess board is set into the small table, sixty four squares of ivory and mahogany, in a circular top. The board is in mid-game, and half a dozen pieces has already been taken, mostly white's. Mandy tries to pick up one of taken pawns, and finds she cannot - it seemed to be glued to the table. She tried a couple more pieces - they all seemed very solidly in place.",
    },  
  ],
})

createItem("chess_pieces", {
  loc:"gallery",
  scenery:true,
  alias:"chess pieces",
  synonyms:['king', 'queen', 'rook', 'castle', 'bishop', 'pawn'],
  examine:"The chess pieces are all wooden and exquisitely carved. The queen looks like a warrior woman in armour, the pawns hold pikes. White pieces seemed to be carved from ivory, whilst black are wooden, but they are otherwise identical.",
  turn:"Mandy tries to turn a few of the chess pieces, but none of them moved at all.",
  take:"The chess pieces seem glued in place; she cannot shift them.",
})

createItem("white_knight", {
  loc:"gallery",
  scenery:true,
  alias:"white knight",
  examine:function() {
    if (this.active) {
      msg("Mandy looks at the white knight. She had not spotted there is only one before, perhaps that is why white is losing. She is not that clear on the game.")
    }
    else {
      msg(w.chess_pieces.examine)
    }
  },
  turn:function() {
    if (this.active) {
      if (w.Patch.leaderName) w.Patch.setLeader()
      msg("Mandy gives the white knight a twist - and suddenly the room is changing around her...")
      player.loc = 'battlefield'
      world.update()
      world.enterRoom()
    }
    else {
      msg(w.chess_pieces.turn)
    }
  }
})





createRoom("gallery_south", {
  windowsface:'none',
  alias:'south end of the gallery',
  headingAlias:"The Gallery (South)",
  desc:"The south end of the gallery is much like the north, if a little darker without the windows; again there are painting along the east wall. The wooden panelling on the walls has warped, and shows sign of damp. There are doors to the south, east and west.",
  west:new Exit("theatre"),
  north:new Exit("gallery", {msg:'The floor boards squeak beneath her, as she heads to the north end.'}),
  east:new Exit("room_small"),
  south:new Exit("upper_steam_hall"),
  east:new Exit("_", {simpleUse:function(char) {
    if (!w.room_big.accessedFrom) w.room_big.accessedFrom = 'gallery'
    const dest = w.room_big.accessedFrom === 'gallery' ? w.room_small : w.room_big
    return util.defaultSimpleExitUse(char, new Exit(dest, {origin:this.origin, dir:this.dir}))
  }}),
  examine_walls:"The walls are panelled with dark wood, but some patcyes are discoloured, and the wood has warped.",
  scenery:[
    {
      alias:['portraits', 'pictures', 'paintings'],
      examine:"The most striking of the paintings is a family portrait, which must be about life size, despite the subjects being painted full length. Mandy can see a father, in suit and top hat, and a mother, together with three young children.",
    },
  ],
})





createRoom("room_big", {
  windowsface:'none',
  alias:"drawing room",
  noFollow:true,
  desc:function() {
    let s = "The drawing room is rather well appointed with wood panelling on the walls, and an ornate ceiling. A f to the east has portraits on either side, whilst the fireplace to the south has a painting of a battle above the mantelpiece."
    if (w.mahogany_cabinet.moved) {
      s += " The mahogany cabinet has been pulled out from the north wall."
    }
    else {
      s += " There is a mahogany cabinet on the north wall."
    }
    return s
  },
  beforeEnter:function() {
    for (let key in w) {
      const item = w[key]
      if (item.size_changing && ['room_small', 'drawing_room_south', 'drawing_room_north'].includes(item.loc)) {
        item.shrink()
        item.loc = "room_big"
      }
    }
  },
  west:new Exit("_", {simpleUse:function(char) {
    const dest = w.room_big.accessedFrom === 'gallery' ? w.gallery : w.gallery_south
    return util.defaultSimpleExitUse(char, new Exit(dest, {origin:this.origin, dir:this.dir}))
  }}),
  scenery:[
    {
      alias:['portraits', 'pictures', 'paintings'],
      examine:"Mandy looks at the three paintings. There are two portraits of girls, one about eight years old, the other maybe twelve. They look alike, perhaps sisters. The other painting is of a great battle in ancient times. The armoured soldiers look like they might be Roman, and have shields and short swords, whilst their opponents have longr swords and axes, but no armour. The Romans seem to be winning.",
    },
    {
      alias:"rug",
      examine:"The rug has a depiction of two lovers kissing, with a geometric pattern around the edge.",
    },
  ],  
})

createItem("mahogany_cabinet", {
  loc:"room_big",
  scenery:true,
  alias:"Mahogany cabinet",
  shiftable:true,
  examine:function() {
    let s = "The mahogany cabinet looks like it came straight out of \"Antiques Roadshow\". Two doors at the front, a curious section on top at the back with four small draws that looks suggestive of a castle wall, with towers at each end."
    if (this.moved) {
      s += " It is standing a little way from the wall and Mandy can just see a hole in the wall behind it a few inches wide."
    }
    msg(s)
  },
  push:function() {
    if (this.moved) return falsemsg("Mandy looks at the cabinet. 'No, not shifting that thing again.'")
    msg("Not sure if she should be moving furniture in someone else's house, Mandy grabs a hold of the cabinet, and heaves it away from the wall, revealing a hole in the wall, a few inches high, just above the skirting board.")
    this.moved = true
    return world.SUCCESS
  },
  pull:function() { return this.push() },
  shift:function() { return this.push() },
})






createRoom("room_small", {
  windowsface:'none',
  alias:'giant drawing room',
  headingAlias:"The Drawing Room (Giant)",
  noFollow:true,
  desc:"This is a drawing room of immense size. Perhaps a hundred meters above her, Mandy can see the ornate ceiling. The walls, panelled in wood, stretch an even greater distance. Huge painting, way about Mandy's head, hang from the walls. In the centre of the room is a thick rug, about the size of a football pitch. The pile is so great, it would stop Mandy going across it. She can, however go round the sides, to the northeast or southeast. The door to the west looks very much out of place, being normal height in such a huge wall.",
  beforeEnter:function() {
    for (let key in w) {
      const item = w[key]
      if (item.size_changing && item.loc === "room_big") {
        item.grow()
        if (item.dest === "north") {
          item.loc = "drawing_room_north"
        }
        else if (item.dest === "south") {
          item.loc = "drawing_room_south"
        }
        else {
          item.loc = "room_small"
        }
      }
    }
  },
  west:new Exit("_", {simpleUse:function(char) {
    const dest = w.room_big.accessedFrom === 'gallery' ? w.gallery_south : w.gallery
    return util.defaultSimpleExitUse(char, new Exit(dest, {origin:this.origin, dir:this.dir}))
  }}),
  northeast:new Exit("drawing_room_north"),
  southeast:new Exit("drawing_room_south"),
  in:new Exit("boots_room", {
    simpleUse:function(char) {
      if (w.boots.loc !== "room_small" || w.boots.size < 6) return falsemsg(lang.not_that_way, {char:char, dir:this.dir})
      return util.defaultSimpleExitUse(char, this)
    },
    msg:"Mandy crawls inside the left boot.",
  }),
  scenery:[
    {
      alias:['portraits', 'pictures', 'paintings'],
      examine:"Mandy looks at the three paintings; two look to be portraits, the other is just a confusing mess. It is hard to see them properly from so far away, and a bad angle.",
    },
  ],
})




createRoom("drawing_room_south", {
  windowsface:'none',
  alias:'south side of the giant drawing room',
  headingAlias:"The Drawing Room (Giant, South)",
  northwest:new Exit("room_small"),
})




createRoom("drawing_room_north", {
  windowsface:'none',
  alias:'north side of the giant drawing room',
  headingAlias:"The Drawing Room (Giant, North)",
  desc:function() {
    let s = "Mandy stands on a narrow strip of wooden floor, between the colossal wall to the north, and the forest-like carpet to the south. To the east, the rug is flush against the wall, so that is not an option, but she can head south west, back to the door."
    if (w.mahogany_cabinet.moved) {
      s += " Above her towers a huge mahogany cabinet, standing proud of the wall. Behind it, to the north, is a large hole in the otherwise perfect wall."
    }
    else {
      s += " Above her towers a huge mahogany cabinet, standing against the wall. There are cracks in the wall behind it, just above the skirting board."
    }
    return s
  },
  southwest:new Exit("room_small"),
  north:new Exit("secret_room", {simpleUse:function(char) {
    if (!w.mahogany_cabinet.moved) {
      msg("No way can Mandy get between the wall and the giant cabinet to go that way.")
      return false
    }
    return util.defaultSimpleExitUse(char, this)
  }}),
})

createItem("cracks_in_the_wall", {
  loc:"drawing_room_north",
  scenery:true,
  examine:function() {
    if (w.mahogany_cabinet.moved) {
      msg("The cracks in the wall surround a hole big enough to climb through.")
    }
    else {
      msg("Looking up behind the giant cabinet, Mandy can see that the cracks lead to a hole in the wall - probably large enough to climb though, if not for the cabinet.")
    }
  },
})

createItem("huge_cabinet", {
  loc:"drawing_room_north",
  scenery:true,
  examine:function() {
    let s = "The mahogany cabinet towers over Mandy; it has to be higher than the science block at Kyderbrook High."
    if (w.mahogany_cabinet.moved) {
      s += " It is standing a little way from the wall - like about 10 foot - and Mandy can see a hole in the wall behind it."
    }
    else {
      s += " Is there something behind it?"
    }
    msg(s)
  },
})




createRoom("secret_room", {
  windowsface:'none',
  headingAlias:"A Secret Room",
  desc:"After the opulence of the other rooms, this one is decidedly bare - but at least it of reasonable proportions. More or less square, the walls are white, or had been at one time. The floor and ceiling are wood.{if:boots:scenery: The only feature of note is a large pair of boots in one corner.}",
  south:new Exit("drawing_room_north"),
})

createItem("boots", SIZE_CHANGING(), {
  loc:"secret_room",
  scenery:true,
  mended:false,
  alias:"pair of boots",
  desc5:"The boots are big, like a size fifteen or something, Mandy reckons. Her dad has big feet, but not like these.",
  desc4:"The boots are tiny, suitable for a doll maybe.",
  desc3:"The boots are almost too small to see.",

  examine:function() {
    if (w.boots.rejectedForStone) {
      w.boots.rejectedForStone = false
      msg("Mandy tips up the left boot, hoping something will fall out - no such luck. She puts her hand inside it, hoping to feel something. There {i:is} something there, she can just touch it with her finger tips. Something thin, stuck right up in the toe. Try as she might, however, she cannot get her hand in far enough to get a grip on it, whatever it is, to pull it out.")
      return true
    }
    if (this.size === this.minsize) {
      msg("{nv:item:be:true} too tiny to see properly!", {item:this})
    }
    else if (this.size === this.maxsize) {
      msg("The boots are huge; she could probably get inside them. Certainly too big to pick up.")
    }
    else {
      msg(this['desc' + this.size] + (this.mended ? ' They look in good condition, now they have been mended.' : ' The toe of the right boot is coming away from the sole.'))
    }
    return true
  },
})




createRoom("boots_room", {
  out:new Exit("room_small", {msg:"Mandy climbs out of the giant boot, thankful to be out of there."}),
  alias:'inside a boot',
  headingAlias:"Inside a left boot",
  afterFirstEnter:function() {
    w.secret_recipe.size = 6
  },
  desc:"The interior of the boot is no more pleasant than the exterior; just darker.{if:secret_recipe:scenery: It looks like there is a huge sheet of thick card, folded into two, wedged in the toe.}",
})

createItem("secret_recipe", SIZE_CHANGING(), {
  alias:"piece of paper",
  synonyms:['huge sheet of card', 'tiny sheet of paper', 'notes'],
  loc:"boots_room",
  scenery:true,
  desc3:"A tiny sheet of folded paper, with writing on one side.",
  desc4:"This sheet of paper has boon folded in two, and has writing on the inside.",
  desc5:"A large sheet of thick card, folded in two; Mandy can see writing on one side.",
  desc6:"A huge sheet of thick card, folded in two; Mandy can see giant writing on one side.",
  alias3:'tiny sheet of paper',
  alias4:'sheet of paper',
  alias5:'sheet of card',
  alias6:'huge sheet of card',
  read:function() {
    if (this.size < 5) return falsemag("The writing is too small to read.")
    let s = ''
    if (this.size === 6) {
      s += "Mandy opens up the huge sheet of card, and reads the giant letters..."
    }
    else {
      s += "Mandy opens up the sheet of paper, and reads the text..."
    }
    s += "\"Notes on the Hourglass of Temporal Hastening. The power of the hourglass can be channelled through a specially prepared conduit into a suitable medium. Once the hourglass has stopped, the organism maintains its state, but only while the hourglass remains in place - once the hourglass is removed, the organism very quickly withers and dies. This is a severe limitation to it practical utility, and needs to be resolved. I have resolved not to use it on a living creature until then.\""
    this.hasBeenRead = true
    msg(s)
  },

  shrink:function() {
    this.size--
    this.setAlias(this['alias' + this.size])
  },

  grow:function() {
    this.size++
    this.setAlias(this['alias' + this.size])
  },

})




createItem("victorian_floor", {
  scenery:true,
  alias:"floor",
  examine:"The floor is wooden, and well-polished.",
})

createItem("victorian_walls", {
  scenery:true,
  alias:"wall",
  examine:"The walls are all panelled in wood.",
})

createItem("victorian_ceiling", {
  scenery:true,
  alias:"ceiling",
  examine:function() {
    if (player.standson === null) {
      msg("The ceiling is white, with simple decorations along each side.")
    }
    else {
      msg("The ceiling turns out to be no more interesting from up here. Mandy wonders why she bothered standing on the {nm:item}.", {item:w[player.standson]})
    }
  },
})

createItem("floor", {
  scenery:true,
  alias:"Floor",
  examine:"Mandy is not quite sure what it is about the tiles. They does not depict a demon or murder or anything really; they just has a strange effect on her eyes that is... disturbing.",
})








