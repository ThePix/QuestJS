"use strict"


register('normality', {
  book:'Antony and Cleopatra',
  uniform:'her grey and blue Kyderbrook High School uniform',
  smell:'The house smells old and musty, like it never gets any fresh air at all.',
  listen:'If she strains, Mandy can hear a quiet humming, and even more faintly a deep, slow rhythmic pulsing sound.',
  floor:"The floor is wooden, and well-polished.",
  walls:"The walls are all panelled in wood.",
  ceiling:"The ceiling is white, with simple decorations along each side.",
})






createRoom("lounge", {
  windowsface:'west',
  desc:"This is a cosy room.",
  west:new Exit("_", {use:function() {
    msg("Mandy steps out of the house, and into the garden. She has escaped at last. Now all she has to worry about is exams in two weeks. Assuming it is still the thirteen of May, 2016...")
    blankLine()
    msg("T H E &nbsp;&nbsp;&nbsp;&nbsp;  E N D", {}, 'centred')
    io.finish()
    return false
  }}),
})


