"use strict"


register('normality', {
  book:'All\'s Well That Ends Well',
  uniform:'her grey and blue Kyderbrook High School uniform',
  smell:'The house smells old and musty, like it never gets any fresh air at all.',
  listen:'If she strains, Mandy can hear a quiet humming, and even more faintly a deep, slow rhythmic pulsing sound.',
  floor:"The floor is wooden, and well-polished.",
  walls:"The walls are all panelled in wood.",
  door:"The door is wood; panelled and unpainted.",
  ceiling:"The ceiling is white, with simple decorations along each side.",
})






createRoom("lounge", {
  windowsface:'west',
  desc:"This is a cosy room. After the chaos of the last few hours, there is a strange sense of normality here; the comfy chairs around the fireplace, the ornaments on the mantelpiece.|The way out of the house, and back to her routine life, Mandy suspects, is west.",
  west:new Exit("_", {use:function() {
    if (player.easterEgg) {
      msg("Mandy steps out of the house, and into the garden. She has escaped at last. Now all she has to worry about is exams in two weeks... But at least she knows what will be on the papers, and has seen the future-Mandy confidently answering the questions. She smiles to herself, feeling strangely confident about the future.")
    }
    else {
      msg("Mandy steps out of the house, and into the garden. She has escaped at last. Now all she has to worry about is exams in two weeks. Assuming it is still the thirteenth of May, 2016...")
    }
    blankLine()
    msg("T H E &nbsp;&nbsp;&nbsp;&nbsp;  E N D", {}, 'centred')
    io.finish()
    return false
  }}),
})


