"use strict"




createItem("player", PLAYER(), {
  loc:"highfield_lane",
  regex:/^(me|myself|player)$/,
  pronouns:lang.pronouns.female,
  examine:"Mandy is just an ordinary 15 year old girl, with dark shoulder-length hair and a nose she feels is too big.",
  silverSpotted:0,
  giveItem:function(options) {},
  parserPriority:-10,
})


createItem("school_bag", CONTAINER(true), {
  loc:"player",
  examine:"Once more Mandy looks at her bag with disgust. She has had it since she is thirteen, when she had really been into One Direction. God, what has she been thinking? She has been asking her dad to get her a new one for like six months. It still has Zayn on it!",
  drop:"Mandy thinks she should hang on to her bag - despite the faces of Harry, Niall, Liam,  Zayn and Louis plastered over it.",
})


createItem("mobile_phone", SIZE_CHANGING(), {
  loc:"school_bag",
  synonyms:['cell phone', 'buttons'],
  use:function() {
    if (this.size === 5) {
      msg("{once:Mandy looks at her phone. 'Shit.' No charge left. She only changed it last night... No, wait, she had found it on her bedroom floor this morning. 'Shit,' she says again.}{notOnce:Mandy looks at her phone, but it stubbornly refuses to have any change.}")
      return true
    }
    else if (this.size === 4) {
      msg("Mandy looks at her shrunken phone. Maybe it was a bit optimistic thinking it would now be charged, just because it is so much smaller.")
      return true
    }
    else if (this.size > 5) {
      msg("Her stupid phone is now too big to use!")
      return false
    }
    else {
      msg("Her stupid phone is now too small to use!")
      return false
    }
  },
  switchon:function() { this.use() },
  desc5:"Mandy looks at her phone. It is soooo old. It even has buttons!",
  desc4:"Mandy's phone is now tiny.",
  desc3:"Mandy's phone is so small she could hardly see it.",
  desc6:"Mandy's phone is now not only way out of date, but also too big to easily carry.",
})


createItem("pen", SIZE_CHANGING(), {
  loc:"school_bag",
  desc5:'{once:At the start of the week, Mandy had three black pens, two blue and one green. Now she only has this stupid green one. Where did they all go?}{notOnce:A stupid green pen.}',
  desc4:"Mandy's pen is now tiny.",
  desc6:"And now she has a {i:huge} stupid green pen.",
})



createItem("shakespeare_book", {
  loc:"school_bag",
  alias:"copy of \"Antony and Cleopatra\"",
  listAlias:"Antony and Cleopatra",
  synonyms:["shakespeare book"],
  state:0,
  zone:'external',
  names:{},
/*    steampunk:'The Tempest',
    central:'Much Ado About Nothing',
    flora:'A Midsummer Night\'s Dream',
    battlefield:'The Taming of the Shrew',
    gothic:'Romeo and Juliet',
    medieval:'Macbeth',
    subterrenea:'Hamlet',
    victorian:'Othello',
    external:'Antony and Cleopatra',
  },*/
  drop:"Mandy definitely does not want to drop the book; Ms Coulter would be furious if she lost it!",
  read:function() {
    this.examine()
    return true
  },
  examine:function() {
    if (this.state === 0 && this.listAlias === "Antony and Cleopatra") {
      msg("Mandy glances at her copy of \"Antony and Cleopatra\". She really should get around to actually reading it some time, what with an exam on it in just a few weeks.")
    }
    else {
      if (this.state === 0) {
        this.state = 1
        msg("Mandy glanced at her copy of \"Antony and Cleopatra\". Wait, this is not the same book! This is {nm:item:a}. What has happened to \"Antony and Cleopatra\"? Ms Coulter will be furious.", {item:this})
      }
      else {
        msg("Mandy looks at the book she now has. {nm:item:a:true}. She wondered if it would be any less boring than \"Antony and Cleopatra\". Probably not worth risking finding out.", {item:this})
      }
      if (w.clockwork_thespian.state > 1 && this.alias === "copy of \"Hamlet\"") {
        msg("Then she remembered the Clockwork Thespian. The soul of wit. Hamlet, act 2, scene 2. Quickly she thumbs through. Brevity! Brevity is the soul of wit.")
        this.state = 2
        w.clockwork_thespian.state = 101
      }
    }
  },
  afterCarry:function() {
    if (this.zone !== currentLocation.zone) {
      this.zone = currentLocation.zone
      this.setAlias("copy of \"" + this.names[this.zone] + "\"", {listAlias:this.names[this.zone]})
      w.uniform.wet = 0
    }
  },
})


createItem("folder", {
  loc:"school_bag",
  scenery:true,
})


createItem("uniform", {
  loc:"player",
  scenery:true,
  alias:"school uniform",
  wet:0,
  wetWords:['dry', 'damp', 'damp', 'wet', 'soaking wet', 'dripping wet'],
  uniforms:{
    external:'her grey and blue Kyderbrook High School uniform',
    victorian:'a rather dowdy grey school uniform that makes her look about fifty',
    flora:'a green and purple school uniform that feels strangely comfortable, even if it looks appalling',
    central:'a deep red school uniform that does not look to bad',
    medieval:'a startling blue and red uniform that is especially uncomfortable',
    steampunk:'a brown uniform, with gold-coloured trim',
    gothic:'a jet black uniform, that looks quite chic',
    subterrenea:'a dark green and yellow uniform that is just about on the cool side of nauseous',
    battlefield:'a red uniform, that looks disturbing like the military uniform of the dead soldiers',
  },
  examine:function() {
    let s = "Mandy is wearing " + this.uniforms[w[player.loc].zone] + "."
    if (this.wet) s += " It is " + this.wetWords[this.wet] + "."
    msg(s)
    if (w[player.loc].zone !== 'external' && !player.uniformnoted) {
      player.uniformnoted = true
      msg("That is definitely not the uniform of Kyderbrook High School that she was wearing when she entered the house!")
    }
  },
  nameModifierFunction:function(list) {
    list.push('worn')
  },
})





//  ----------- GENERIC ITEMS ---------------------------


const GENERIC = function() {
  return {
    scenery:true,
    isLocatedAt:function(loc, situation) {
      const room = w[loc]
      if (!room.zone) return false
      if (w[loc + '_' + this.alias]) return false
      if (zones[room.zone][this.alias]) return true
      return false
    },
    examine:function() {
      const room = w[player.loc]
      if (typeof room['examine_' + this.alias] === 'function') {
        room['examine_' + this.alias]()
      }
      else if (typeof room['examine_' + this.alias] === 'string') {
        msg(room['examine_' + this.alias])
      }
      else {
        msg(zones[room.zone][this.alias])
      }
    }  
  }  
}

createItem("generic_wall", GENERIC(), {
  alias:"walls",
})

createItem("generic_floor", GENERIC(), {
  alias:"floor",
})

createItem("generic_ceiling", GENERIC(), {
  alias:"ceiling",
})


createItem("generic_window", {
  isLocatedAt:function(loc) {
    return w[loc].windowsface !== undefined && w[loc].windowsface !== 'none'
  },
  alias:"window",
  scenery:true,
  roomsmashed:false,  // this will be the name of room where window is smashed
  examine:function() {
    const windowsface = w[player.loc].windowsface
    if (w.generic_window.roomsmashed) {
      if (player.loc === this.roomsmashed || this.noted) {
        msg("Mandy looks at the bricked-up window. No way is she getting out that way.")
      }
      else {
        msg("Mandy looks at the bricked-up window. No way is she getting out that way. Wait. The window she smashed is in {nm:room:the}. Why is this window bricked-up too?", {room:w[this.roomsmashed]})
        this.noted = true
      }
    }
    else if (windowsface === "north") {
      msg("Mandy looks out the window at the countryside; fields, trees, and there is her home, a barn conversion her parents purchased three years ago. But how could that be? No way is her home visible from this house; Highfield Lane twists around far too much for that.")
    }
    else {
      msg("Mandy looks out the window at the countryside; fields, trees, and there is her home, a barn conversion her parents purchased three years ago. But how could that be? This window faces " + windowsface + " and her home is to the north.")
    }
  },
  smash:function() {
    if (this.bricked_up) return falsemsg ("Mandy considered breaking a window again... Of course, smashing a bricked-up window is not something she is likely to be able to do.")

    msg ("{i:Fuck this,} think Mandy. {i:I'm getting out of here.} A little gingerly despite her resolve, Mandy knocks on the glass. Nothing happens, so she hits it hard. Smash! It shatters into thousands of pieces.")
    msg("Beyond is only blackness. For one vertiginous moment she stared into the void...")
    msg("Then suddenly a figure appears on the other side of the window. Human in shape - more or less - but silver-grey, as though made of stone or maybe metal, it works with blinding speed, placing brick after brick to seal up the window.")
    w.glass_shards.loc = player.loc
    this.bricked_up = true
    this.roomsmashed = player.loc
  },
})

createItem("glass_shards", {
  pronouns:lang.pronouns.plural,
  alias:"shards of glass under the bricked-up window",
  examine:function() {
    msg("The shards are the remains of the window. Jagged pieces of glass, some as long as her arm, some almost too small to see. They seem to be reflecting the countryside outside the house somehow...")
  },
  take:function(options) {
    if (w.glass_shard.loc) {
      msg("Mandy has already taken one glass shard; she decides she does not want to risk cut fingers by taking any more.")
      return false
    }
    if (!options.char.canManipulate(this, "take")) return false
    msg("Mandy carefully picked up one of the shards of glass.")
    w.glass_shard.moveToFrom(options, "name", "loc")
    return true
  },
})


// want to limit to one
createItem("glass_shard", TAKEABLE(), {
  alias:"glass shard",
  examine:function() {
    msg("Mandy carefully looks at the shard of glass. Through it she could still see the countryside near her home. She turned it over, and there it is again, but from this side the view is reversed, as though seen through a mirror.")
  },
})
