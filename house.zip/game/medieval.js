"use strict"



register('medieval', {
  book:'Hamlet',
  uniform:'a startling blue and red uniform that is especially uncomfortable',
  smell:'The room does not smell good; there is a definitely odour of dung.',
  listen:'Mandy can hear nothing.',
  floor:"The floor is rough wood.",
  walls:"The walls are all rough-cut stone.",
  ceiling:"The ceiling is wood, like the floor, supported by thick beams.",
})





createRoom("great_gallery", {
  windowsface:'north',
  examine_ceiling:function() { msg("The stone bricks of the walls curve over to form a vaulted roof to the room.") },
  desc:"The great gallery is a wooden platform that overlooks the great hall, running along the north and east sides of it. A wide flight of wooden stairs leads back down to the hall, while a narrow spiral staircase goes further upwards. The walls are of rough-cut stone. Doorways are east, south and west; together with a a rather low doorway north.{if:spike:alias:mangled metal: There is a black line running from the observatory, down to the Great Hall.}",
  down:new Exit("great_hall"),
  south:new Exit("solar"),
  north:new Exit("nursery", {msg:'Mandy has to stoop to get through the narrow door to the north.'}),
  east:new Exit("brass_dining_room", {simpleUse:function(char) {
    if (w.brass_dining_room.blocked()) return falsemsg("Mandy starts heading east, but the dining room is now so full of mannequins, she cannot get into it.")
    return util.defaultSimpleExitUse(char, this)
  }}),
  up:new Exit("observatory"),
  west:new Exit("greenhouse_catwalk_east"),
  afterEnter:function() {
    if (w.uniform.wet === 4) { 
      w.uniform.wet = 2
    }
  },
  scenery:[
    { alias:['balustrade', 'banister', 'handrail'], examine:'A study, but rough-cut balustrade runs the length of the gallery.'},
  ]
})




createRoom("great_hall", {
  windowsface:'north',
  desc:"The great hall is an impressive size. It looks older than the rest of the house, a lot older, being built of rough-cut stone. There are doors to east and west, and a wooden staircase leads up to a wooden gallery that ran along the west side of the hall. To the south, a doorway leads to a flight of steps heading downwards.{if:spike:alias:mangled metal: There is a black line running from the gallery, down to the lab.}",
  examine_floor:function() { msg("The floor is composed of flagstones, of the same mid-grey as the walls. It looks a little uneven in places.") },
  examine_ceiling:function() { msg("The stone bricks of the walls curve over to form a vaulted roof to the room, up above the gallery.") },
  up:new Exit("great_gallery"),
  down:new Exit("mad_science_lab"),
  south:new Exit("mad_science_lab"),
  west:new Exit("greenhouse_east"),
})




createRoom("solar", {
  windowsface:'south',
  desc:"The solar. Mandy knows the name from history class; this is where the lord of the castle would sleep. None too comfortable to Mandy's eyes, but possibly the height of luxury a thousand years ago. A large bed, crudely built of wood; a tapestry hung from one wall{if:chamber_pot:scenery:; a chamber pot under the bed}.",
  north:new Exit("great_gallery"),
  scenery:[
    {alias:'bed', examine:'The bed is a four-poster, but not ornate at all, and surprisingly small; probably a bit wider than her own bed, but not as long.'},
    {alias:'tapestry', examine:'The tapestry has a rather impressive image of a knight fighting a dragon, though time has muted the colours.'},  
  ],
})

createItem("chamber_pot", SIZE_CHANGING(), VESSEL(), {
  loc:"solar",
  scenery:true,
  msgTake:"{ifNot:chamber_pot:scenery:" + lang.take_successful + ":Mandy takes the chamber pot, trying desperately not to think about what it has been used for. At least it is empty...}",
  desc5:'A chamber pot, useful for... something?{chamber_pot}',
  desc4:'A tiny chamber pot, probably not useful for anything.{chamber_pot}',
  desc6:'A huge chamber pot, useful for... She decides she would rather not think about that!{chamber_pot}',
  desc7:'An enormous chamber pot, almost big enough to use as a boat!{chamber_pot}',
  testFill:function(options) {
    if (this.size > 5) {
      msg("Mandy thinks about filling the chamber pot with " + options.fluid + ", but it is so big, she would never be able to lift it.")
      return false
    }
    if (options.fluid === 'water' && player.loc === 'beach') {
      msg("Mandy thinks about filling the chamber pot with water from the sea, but just the sight of those bodies in it is making her feel nauseous. No way is she going near that water.")
      return false
    }
    return true
  },
  nameModifierFunction:function(list) {
    if (this.containedFluidName) list.push('full of ' + this.containedFluidName)
  },
  testCarry:function() {
    if (this.loc === player.name && this.size === 7 && this.containedFluidName) return falsemsg('Mandy starts to the door, but the weight of the enormous chamber pot full of {show:fluid} is just too much for her to lug around.', {fluid:this.containedFluidName})
    return true
  },
})
tp.addDirective("chamber_pot", function(arr, params) {
  if (!w.chamber_pot.containedFluidName) return ''
  return ' It is full of ' + w.chamber_pot.containedFluidName + '.'
})




createRoom("mad_science_lab", {
  windowsface:'none',
  alias:"mad science laboratory",
  smell:function() { 
    if (w.spike.alias === 'mangled metal') {
      msg("There is a strong smell burnt rubber, but is there a hint of something else? Ozone, maybe?") 
    }
    else {
      msg("Mandy warily sniffs the air; it is not a pleasant smell. Acrid, a bit like vinegar, but not quite.") 
    }
  },
  examine_floor:function() { msg("The floor is packed earth; there are patches that look darker, where something might have been spilt perhaps.") },
  examine_ceiling:function() { msg("The stone bricks of the walls curve over to form a vaulted roof to the room.")},
  desc:function() {
    let s = "This appears to be some kind of laboratory, though nothing like the ones at school. While they have their own distinctive smell, this room is "
    s += w.spike.alias === 'mangled metal' ? 'altogether worse, with a strong smell of burnt rubber' : 'different, though Mandy is not sure what it is'
    s += ". The room is dominated by a very solid wooden bench"
    if (w.patchwork_body.isHere("this")) {
      if (w.patchwork_body.loc || w.Patch.state === 0) {
        s += ", with a corpse on it; is it there to be dissected?"
      }
      else {
        s += ", with a patchwork body on it."
      }
      s += " A strange device that stands at the head of the table, connected to the body by a number of thick wires"
    }
    else {
      s += ". At one end of the bench a strange device stands with wires dangling from it"
    }
    if (w.wire.scenery) {
      s += ", and a coil of wire sits on the floor beside it"
    }
    s += ". Above the table, a crocodile is suspended."
    if (w.mad_science_journal.scenery) {
      s += " Mandy can also see a journal lying in a corner, as though tossed there in anger."
    }
    return s
  },
  afterEnterIf:{
    patchAnimated:{
      test:function() { return w.Patch.loc === 'mad_science_lab' },
      action:function() {
        msg("Mandy notices the body on the bench twitching, then it raises its right arm, and looks at it. 'It's alive!' she cackles, because, really, what else is one supposed to do after animating a body with lightning?")
      },
    },
    //w.h_find_animate_corpse.passed = true
  },
  up:new Exit("great_hall"),
  north:new Exit("great_hall"),
})

createItem("stuffed_crocodile", {
  loc:"mad_science_lab",
  scenery:true,
  examine:"The crocodile is a little over a meter long, and hanging from the ceiling on four wires. It looks like it is stuffed, and it is kind of creeping imagining that once it was been alive.",
  take:'The crocodile is too high for Mandy to reach.',
})

createItem("mad_science_bench", {
  loc:"mad_science_lab",
  scenery:true,
  alias:"bench",
  examine:"The wood of the bench has black rings and circles scorched into it, testament to years of use. Or perhaps week of use by an inept experimenter, Mandy muses.",
  take:'The bench is far to heavy for Mandy topick up.'
})

createItem("patchwork_body", {
  loc:"mad_science_lab",
  alias:"patchwork body",
  scenery:true,
  state:0,
  examine:function() {
    this.state = 1
    msg("Mandy gingerly inspects the corpse on the table. It is naked, but nothing to suggest it is either male or female. As she looks closer, she can see stitch marks, and with a growing sense of nausea, she realises it is not a corpse, but the stitched together parts of several corpses.")
  },
})

createItem("Patch", NPC(false), {
  alias:"animated corpse",
  synonyms:['patch', 'patchwork body'],
  state:0,
  afterMove:function() { this.huggingTree = false },
  examine:function() {
    let s
    if (this.state === 0) {
      s = "Mandy looks at the creature she bought to life. It is about two and a half meters tall, and very solidly built. Patches of it are hairy, other patches are dark skinned, some light skinned. Its face is not attractive, it too is a mishmash of parts. Mandy really does not want to know where all the parts came from. However, it needs a name... 'I'll call you Patch,' she says. It nods it head, possibly in acknowledgment."
      this.nameMe()
    }
    else {
      s = "Mandy looks at Patch, the creature she bought to life. He is about two and a half meters tall, and very solidly built. Patches of him are hairy, other patches are dark skinned, some light skinned. His face is not attractive, it too is a mishmash of parts. Mandy really does not want to know where all the parts came from."
    }
    if (w.boots.isAtLoc("Patch")) {
      if (w.boots.lacedup) {
        s += " He is wearing a pair of boots, neatly laced up."
      }
      else {
        s += " He is wearing a pair of boots, unlaced."
      }
    }
    if (this.huggingTree) s += ' He is currently hugging a tree.'
    msg(s)
  },

  nameMe:function() {
    this.setAlias("Patch")
    this.state = 1
    this.properNoun = true
  },
  talktoOptions:[
    "'So, do you come here often,' Mandy asks Patch. He gave no indication either way.",
    "'Tell me about yourself,' says Mandy to Patch. His silence suggested there is not much to tell. Or he is unable to talk.",
    "'Where now, do you think,' Mandy asks Patch. Patch seemed as stumped as Mandy.",
  ],
  talkto:function() {
    if (this.state = 0) {
      msg ("'I shall call you \"Patch\",' declares Mandy.")
      msg ("The animated body seemed to stand a little taller, Mandy thinks, proud to have a name.")
      this.nameMe()
    }
    else {
      msg(this.talktoOptions[GetRandomInt(1, 3)])
    }
    return true
  },
  endFollow:function() {
    msg("'Wait here,' says Mandy to {nm:npc:the}.", {npc:this})
    if (!this.leaderName) return falsemsg("{nv:npc:look:true} at Mandy is confusion.", {npc:this})
    this.setLeader()
    msg("{nv:npc:nod:true} his head.", {npc:this})
    return true
  },
  startFollow:function() {
    msg("'Follow me,' says Mandy to {nm:npc:the}.", {npc:this})
    if (this.leaderName) return falsemsg("{nv:npc:look:true} at Mandy is confusion.", {npc:this})
    this.setLeader(player)
    msg("{nv:npc:nod:true} his head.", {npc:this})
    return true
  },
  testFollowTo:function(room) {
    if (!room.noFollow) return true
    msg("Mandy realises Patch is no longer following her.")
    this.setLeader()
    return false
  },
  giveItem:function(options) {
    if (options.item === w.boots) {
      options.item.loc = player.name
      options.item.worn = false
      this.animated = false
      msg("'Give me the boots,' says Mandy.")
      msg("{nv:char:look:true} at her in surprise, then sadness. Forlornly he sits on the floor, and slowly pulls off the boots, before handing them to Mandy. Mandy cannot look at his face without feeling guilty.", options)
      return true
    }
    if (options.item.name.startsWith('tamarind_pod_prototype')) {
      msg("'Give me the tamarind,' says Mandy.")
      msg("{nv:char:look:true} at the pod in his hand, then at Mandy. After a moment's deep thought, he hands her the pod.", options)      
      options.item.loc = player.name
      return true
    }
  },
  afterGive:function(options) {
    if (options.item === w.boots) {
      if (w.boots.size < 5) {
        options.item.loc = this.loc
        return falsemsg("Mandy gives the boots to {nm:npc:the}. He looks at the tiny footwear in confusion, before dropping them on the floor.", options)
      }
      if (!w.boots.mended) {
        options.item.loc = this.loc
        w.boots.rejectedForHole = true
        return falsemsg("Mandy gives the boots to {nm:npc:the}. He looks at the footwear at first with a big smile, which turns into a forlorn frown when he finds the right boot is coming apart. Sadly, he drops them on the floor.", options)
      }
      if (w.secret_recipe.loc === 'boots_room') {
        options.item.loc = this.loc
        msg("Mandy gives the boots to {nm:npc:the}. He looks at the footwear with a big smile, then proceeds to pull on the left boot... Suddenly his grin turns to a frown, and he pulls off the boot, dropping both on the floor.", options)
        if (w.boots.rejectedForHole = true) {
          msg("'For fuck's sake,' mutters Mandy, 'now what? Is there a stone in it or something?'")
        }
        else {
          msg("'What the...' mutters Mandy, 'Is there a stone in it or something?'")
        }
        w.boots.rejectedForStone = true
        return false
      }
      options.item.loc = this.name
      options.item.worn = true
      this.animated = true
      msg("Mandy gives the boots to {nm:npc:the}. He looks at the footwear with a big smile, then proceeds to pull on the left boot... Then the right. He looks at them, now on his feet, for a moment, before getting off the bench, and standing upright, ripping of all the wires connecting him to the strange device.", options)
      return true
    }

    options.item.loc = this.loc
    return falsemsg("Mandy gives {nm:item:the} to {nm:patch:the}. {np:patch:look} at {sb:item} in confusion, before dropping {sb:item} to the floor.")
  }
})
w.Patch.nameModifierFunctions[0] = function(item, l) {
  if (w.boots.loc === 'Patch') l.push('wearing a pair of boots')
  if (w.Patch.hasPod) l.push('holding a tamarind pod')
}

createItem("strange_device", {
  loc:"mad_science_lab",
  alias:"strange device",
  scenery:true,
  examine:function() {
    let s = "The machine at the head of the table is about a meter and a half tall; a wooden cabinet, with brass fittings. On the front are a series of dials and knobs. "
    let body
    if (w.patchwork_body.isAtLoc("mad_science_lab")) {
      body = w.patchwork_body
      s += "About a dozen wires run from the machine to the body, each attached to its own brass bolt on the machine, and to a clip on the torso."
    }
    if (!w.Patch.animated) {
      body = w.Patch
      s += "About a dozen wires run from the machine to {nm:item:the}, each attached to its own brass bolt on the machine, and to a clip on his torso."
    }
    else {
      s += "About a dozen wires hang down from the machine, each attached to its own brass bolt on the machine."
    }
    if (w.spike.alias === 'mangled metal') s += ' There is smoke coming from the back of it.'
    msg(s, {item:body})
  },
})

createItem("wire", ROPE(7, "strange_device"), {
  loc:"mad_science_lab",
  alias:"wire",
  synonyms:['coil'],
  pronouns:lang.pronouns.massnoun,
  indefArticle:'some',
  scenery:true,
  msgUnwind:"The wire trails behind as Mandy unwinds it.",
  msgWind:"Mandy coils up the wire.",
  msgTake:"She takes the coil of wire.",
  examine:function() {
    let s = "The wire is about a millimetre thick, and "
    let length = this.locs.length
    if (this.isHeld()) length--
    if (length === 1) {
      s += "she guesses there is about " + lang.toWords(5 * this.ropeLength) + " metres of it, the end of which is soldered to the side of the machine at the head of the table on the wall."
    }
    else if (length === 2) {
      s += "she guesses there is about twenty metres of it on the spindle, which is also metal, and more heading down the stairs to the laboratory."
    }
    else if (length === this.ropeLength - 1) {
      s += "there is not much left."
    }
    else if (length === this.ropeLength) {
      s += "she is holding just the end of it."
    }
    else {
      s += "she guesses there is about " + lang.toWords(5 * (this.ropeLength - length)) + " metres of it in a coil; more is heading back to the laboratory."
    }
    this.examined = true
    msg(s)
  },

  suppessMsgs:true,
  attachTo:function(char, item) {
    this.loc = item.name
    this.tiedTo2 = item.name
    if (item === w.spike) {
      msg("Mandy wraps the wire from the spindle around the letter E on the weather vane, then lets the spindle drop, happy that it is secure.")
      if (w.sky.state < 5) { 
        w.sky.state = 5
        msg("A brief flash of lightning lights up the weather vane, and a few seconds later Manda hears the thunder.")
      }
    }
    else {
      msg("Mandy attaches the wire from the spindle to {nm:item:true}, then lets the spindle drop.", {item:item})
    }
  },
  detachFrom:function(char, item) {
    this.tiedTo2 = false
    item.loc = player.name
    if (item === w.spike) {
      msg("Mandy unwraps the wire from the spindle around the letter E on the weather vane.")
    }
    else {
      msg("Mandy detaches the wire from {nm:item:true}.", {item:item})
    }
  },  
  
  afterMove:function() {
    if (!this.examined) {
      this.examined = true
      msg("Mandy realises one end of the wire on the spindle is soldered to the strange machine.")
    }
    if (!this.moved) this.moved = true
  },

})

createItem("mad_science_journal", TAKEABLE(), {
  loc:"mad_science_lab",
  scenery:true,
  examine:"The journal is in a bad condition; it looks like various things have been split on it, including acid, given the entire bottom right corner is missing. it looks old too - or at least old fashioned - and is bound in leather.",
  read:"Mandy leafs though the journal, scanning the pages. Most of it makes as little sense as her \"Chemistry in Context\" text book, and the handwriting does not help. What the hell is a homunculus? The last third of the journal is empty, but the last entry say: \"I am so near, all I need is the vital spark. Weather vane on the Great Hall?\"",
})




createRoom("observatory", {
  windowsface:'none',
  desc:"The room is dominated, filled even, by a telescope and its supporting mechanism, which is not difficult, as the room is not big. There are some controls on the wall, and the only exit is the stairs she has just come up.{if telescope.roofopen: A section of roof is open on the west side of the dome.}{if:spike:alias:mangled metal: There is a black line along the floor marking where the wire had been before the lightning strike.}",
  down:new Exit("great_gallery"),
  up:new Exit("observatory_up", {alsoDir:['climb'], msg:'She clambers up the telescope.'}),
  afterEnter:function() {
    if (w.uniform.wet === 4) { 
      w.uniform.wet = 3
      msg("She is dripping water on to the floor.")
    }
  },
  examine_ceiling:function() {
    let s = "The observatory is a domed roof, perhaps made of wood, painted an off-white colour."
    if (w.telescope.roofopen) {
      s += " There is a vertical slot open in the roof through which someone using the telscope could observe the stars."
      if (w.telescope.azimuth !== 6) {
        s += " All Mandy can see through the slot is a dark and threatening sky."
      }
      else if (player.loc === 'observatory') {
        s += " All Mandy can see through the slot is a dark and threatening sky and the top of a weather vane."
      }
      else {
        s += " All Mandy can see through the slot is a dark and threatening sky and a weather vane on a nearby roof."
      }
    }
    msg(s)
  },

})



createItem("telescope", {
  loc:"observatory",
  scenery:true,
  alias:"telescope",
  roofopen:false,
  azimuth:1,
  altitude:7,
  altitudes:[
    'horizontal',
    'nearly horizontal',
    'slightly raised',
    'somewhat raised',
    'diagonal',
    'raised up',
    'raised high',
    'nearly vertical',
  ],
  azimuths:['north', 'northeast', 'east', 'southeast', 'south', 'southwest', 'west', 'northwest'],
  examine:function() {
    let s = "The telescope itself is about two meters long. It is held in place by a complicated mechanism, involving cogs and gears, and the whole thing is made of brass, giving it a strange beauty."
    s += " It is currently " + this.altitudes[this.altitude] + ","
    s += " and pointing " + this.azimuths[this.azimuth] + "ward."
    msg(s)
  },
  use:function() {
    if (w.telescope.roofopen) {
      msg("Mandy looks though the eye-piece at the side of the base of the telescope. For a moment, all she can see is the reflection of her eyelashes, but she opens her eyes wide, and can see... clouds. And they look pretty much the same as they do without a telescope.")
    }
    else {
      msg("Mandy looks though the eye-piece at the side of the base of the telescope, but all she can see a uniform off-white. Exactly the same colour as the ceiling...")
    }
    return true
  },
  lookthrough:function() { return this.use() },
  climbverb:function(options) {
    return currentLocation.up.use(options.char)
  },
})

createItem("controls", {
  loc:"observatory",
  scenery:true,
  alias:"controls",
  examine:"The controls consist of two wheels, one on the left, one on the right, and a lever, all set into a panel, all in brass.",
})

createItem("left_wheel", {
  // azimuth
  loc:"observatory",
  scenery:true,
  alias:"left wheel",
  examine:"The left wheel is about seven centimetres across, and made of brass.",
  turn:"Mandy looks at the wheel, wondering if she wants to turn it left or right...",
  turnleft:function() { 
    w.telescope.azimuth--
    if (w.telescope.azimuth < 0) w.telescope.azimuth = w.telescope.azimuths.length - 1
    msg("With a grunt of effort, Mandy turns the left wheel a full rotation anti-clockwise - it is hard work! As she does the entire telescope, and the mechanism holding it, rotates, with a painful grinding noise. At the same time, the ceiling also turns.")
    return true
  },
  turnright:function() { 
    w.telescope.azimuth++
    if (w.telescope.azimuth >= w.telescope.azimuths.length) w.telescope.azimuth = 0
    msg("Mandy turns the left wheel a full rotation clockwise, and as she does the entire telescope, and the mechanism holding it, smoothly rotates. At the same time, the ceiling also turns.")
    return true
  },
})

createItem("right_wheel", {
  // altitude
  loc:"observatory",
  scenery:true,
  alias:"right wheel",
  examine:"The left wheel is about seven centimetres across, and made of brass. There is a set of numbers on dials, like a gas meter, just above the wheel, showing {show:telescope:altitude}.",
  turn:"Mandy looks at the wheel, wondering if she wants to turn it left or right...",
  turnleft:function() {
    if (w.telescope.altitude === 0) {
      msg("Mandy tries to move the right wheel clockwise, but it will not turn any more.")
      return false
    }
    w.telescope.altitude--
    msg("Mandy turns the right wheel a full rotation clockwise, and as she does the telescope lowers.")
    return true
  },
  turnright:function() { 
    if (w.telescope.altitude === w.telescope.altitudes.length - 1) {
      msg("Mandy tries to move the right wheel anti-clockwise, but it will not turn any more.")
      return false
    }
    w.telescope.altitude++
    msg("Mandy turns the right wheel a full rotation anti-clockwise, and as she does the telescope rises.")
    return true
  },
})

createItem("lever", {
  loc:"observatory",
  scenery:true,
  examine:"A small brass level, currently in the {if:telescope:roofopen:down}{ifNot:telescope:roofopen:up} position.",
  push:function(options) {
    const verb = parser.currentCommand.cmd.name.toLowerCase()
    if (w.telescope.roofopen) {
      msg("{nv:char:" + verb + ":true} the lever up, and the slot in the ceiling slides closed.", options)
      w.telescope.roofopen = false
    }
    else {
      if (!this.used) {
        msg("{nv:char:" + verb + ":true} the lever down, and a huge slot in the ceiling opens up, directly in front of the telescope, allowing anyone using the telescope to actually see the sky.|{nv:char:glance:true} outside; the sky looks threatening. It had been quite nice before {ob:char} entered the house.", options)
        this.used = true
      }
      else {
        msg("{nv:char:" + verb + ":true} the lever down, and the huge slot in the ceiling opens up.", options)
      }
      w.telescope.roofopen = true
    }
    return true
  },
  pull:function(options) { return this.push(options) },
})




createRoom("observatory_up", {
  windowsface:'none',
  alias:'up on the telescope',
  headingAlias:"The Observatory (On The Telescope)",
  noFollow:true,
  desc:function() {
    let s = "Mandy stands - somewhat precariously - on the top of the mechanism that supports the telescope."
    return s
  },
  noFollow:true,
  afterEnter:function() {
    if (w.uniform.wet === 5) { 
      w.uniform.wet = 4
      msg("At least she is out of the rain now!")
      if (w.wire.tiedTo2 === 'spike') {
        msg("Suddenly there is a huge crack of thunder and a flash of light, making Mandy shriek in shock.")
        w.spike.setAlias('mangled metal')
        delete w.wire.tiedTo2
        delete w.wire.loc
        delete w.patchwork_body.loc
        w.Patch.loc = 'mad_science_lab'
      }
    }
  },
  down:new Exit("observatory", {alsoDir:['climb_down']}),
  examine_ceiling:function() { w.observatory.examine_ceiling() },
  afterDropIn:function(item) { item.loc = 'observatory' }
})
for (const dir of w.telescope.azimuths) {
  w.observatory_up[dir] = new Exit("roof_location_east", {
    isHidden() {
      return (dir !== w.telescope.azimuths[w.telescope.azimuth])
    },
    simpleUse:function(char) {
      if (this.dir !== w.telescope.azimuths[w.telescope.azimuth]) return falsemsg(lang.not_that_way, {char:char, dir:dir})
      if (w.telescope.altitude > 4) return falsemsg("Mandy looks at the end of the telescope; if it was not so steep, she could edge along it, and perhaps get out onto the roof to the east.")
      if (!w.telescope.roofopen) return falsemsg("Mandy looks at the end of the telescope; if she wanted to she could probably edge along it and touch the curved ceiling of the observatory. {i:And why the hell would I want to that?} she says to herself.")
      if (w.telescope.azimuth !== 6) return falsemsg("Mandy looks at the end of the telescope; if she wanted to she could probably edge along it and then get out though the slot in the roof, then slide down the outside of the observatory, plummeting to her death.")
      return util.defaultSimpleExitUse(char, this)
    },
    msg:"Mandy cautiously edges along the telescope to the very end, then reaches over to the opening the roof. She climbs though, and for a moment is balanced precariously on the botton of the slot, before she jumps onto the adjacent roof.",
  })
}

createItem("telescope_while_on_it", {
  loc:"observatory_up",
  scenery:true,
  alias:"telescope",
  examine:function() { w.telescope.examine() },
  use:function() { return falsemsg("She cannot use the telescope while climbing on it.") },
  lookthrough:function() { return falsemsg("She cannot look though the telescope while climbing on it.") },
  climbdownverb:function(options) {
    return currentLocation.down.use(options.char)
  },
})



createRoom("roof_location_east", {
  alias:'east end of the roof',
  headingAlias:"On A High Roof (East)",
  desc:"Mandy is stood - rather nervously - on the apex of a roof.",
  afterEnter:function() {
    if (this.visited === 1) {
      msg("She is far above the ground. Not just scary far but also does-not-make-sense far above the ground. It is a two story house! Then again, she is pretty sure number 23 does not have an observatory at the back.")
      msg("As she looks harder, she realises she cannot see the Ash Tree Estate, instead there are only fields. Perhaps no bad thing, she thinks, but then she noticed that there is no modern housing at all. This is what the town would have looked like before the war. Possibly before the first world war.")
    }
    if (w.wire.isAtLoc(player) && w.sky.state < 3) { 
      w.sky.state = 3
      msg("Suddenly the rain starts. 'Shit,' she screams at the sky, as she is quickly soaked to the skin. It was supposed to be sunny today!")
      w.uniform.wet = 5
    }
    if (w.wire.tiedTo2 === 'spike' && w.sky.state < 6) { 
      w.sky.state = 6
      msg("Is the rain getting worse? She did not think that was possible.")
    }
  },
  east:new Exit("observatory_up", {msg:'Mandy nervously jumps back on to the sill of opening in the observatory roof. After a moment to catch her breath, she reaches across, to grab the telescope, and then edges back, to stand on the mechanism.'}),
  west:new Exit("roof_location_west", {msg:'Mandy starts to edge along the roof, then decides she would prefer to crawl. She gets on her hands and knees, and feeling marginally safer makes her way to the west end of the roof.'}),
  testDropIn:function() { return falsemsg("It occurs to Mandy that anything she drops here will fall down the roof, and will be lost forever.") },
})



createRoom("roof_location_west", {
  alias:'west end of the roof',
  headingAlias:"On A High Roof (West)",
  desc:"Mandy is at the west end of the ridge of the roof, beside a weather vane{ifMoreThan:sky:state:3:, in the driving rain}.",
  testDropIn:function() { return falsemsg("It occurs to Mandy that anything shre drops here will fall down the roof, and will be lost forever.") },
  afterEnter:function() {
    if (w.wire.isAtLoc(player) && w.sky.state < 4) { 
      w.sky.state = 4
      msg("Mandy sees lightning in the hills to the north - somewhere around her home, she supposes. A few seconds later she can hear the thunder. It occurs to her that being up on the roof holding something metal is not the safest of things to do. Maybe some haste is in order.")
    }
  },
  east:new Exit("roof_location_east", {msg:'Mandy crawls back along the apex of the roof, towards the dome of the observatory.'}),
})

createItem("spike", {
  loc:"roof_location_west",
  alias:'weather vane',
  scenery:true,
  attachable:true,
  examine:function() {
    if (w.wire.getState() === 2) {
      msg("The weather vane is a twisted lump of black metal. Two rods stick out, with \"N\" and \"W\" of them, the only hint of what it used to be.")
      return
    }
    let s = "The weather vane is made of black metal. Above the traditional compass points, a flat raven, sat on an arrow, swings round with each gust of wind."
    if (w.wire.tiedTo2 === this.name) {
      msg(" A metal wire is attached to the letter E.")
    }
    msg(s)
  },
})


/*
 2  start
 3  roof east with wire, starts to rain
 4  roof west with wire, lightning
 5  wire tied on (but could later get untied)
 6  roof east, wire tied on


20  all done, clear skies
*/

createItem("sky", {
  isLocatedAt:function(loc) { return loc.startsWith("roof_location") },
  scenery:true,
  state:2,
  examine:function() {
    switch (this.state) {
      case 20:
        msg("The sky is blue, with the odd fluffy cloud.")
        break
      case 2:
        msg("The dark clouds threatened rain at any moment.")
        break
      default:
        msg("The sky is looking thundery; rain is pouring hard.")
        break
    }
  },
})

















/*


This room resets when the balloon touches the floor

The player needs to:
enter
open doll's house
talk to man
give boots to man
wait
get boots

get balloon, touch, move, knock, etc. heads it up,



*/



createRoom("nursery", {
  windowsface:'north',
  noFollow:true,
  desc:"This seemed to be a nursery, or at least what a nursery might have looks like a century ago. {if:china_doll:scenery:A china doll is sat on a chair, and there is a doll's house near them:On the far side of the room, there is a chair and a doll's house}. Mandy can also see a cream-painted cot near the window{ifExists:yellow_balloon:loc:, and a balloon..}.",
  convReset:function() {
    for (const el of scopeBy(el => el.belongsTo && el.belongsTo('tiny_man'))) {
      itm.showTopic = false
      itm.hideTopic = false
      log("resetting: " + itm.name)
    }
    tinyman_hello.display = true
  },  
  south:new Exit("great_gallery", {msg:"Mandy ducks down to go out the door, and as she does a sudden flash of light momentarily disorientates here."}),
  scenery:[
    {alias:'chair', examine:'A simple wooden chair; small, as though for a child.'},
  ],
})


createItem("china_doll", TAKEABLE(), {
  scenery:true,
  loc:"nursery",
  msgTake:"{if:china_doll:scenery:Mandy picks up the china doll because you never know when a creepy top is going to come in useful. The body is soft and floppy, and the contrast with the head is a little disturbing.|'Help me!' says a tiny voice. Was that the doll speaking?:Mandy picks up the china doll.}",
  examine:"The doll is about 40 cm tall, or would be she stood upright - she clearly is supposed to be female. Her head and shoulders are glazed porcelain, including her dark hair and blue eyes; she has very rosy cheeps. She is wearing quite a fancy burnt umber dress, with belt and buttons. There is something creepy about her.",
})


createItem("yellow_balloon", {
  loc:"nursery",
  scenery:true,
  alias:"yellow balloon",
  states:[
    'The balloon is near the ceiling, but seems to be falling...',
    'The balloon, gently falling from the ceiling, is at about head height.',
    'The balloon has drifted down to about waist height.',
    'The balloon is at knee height, floating downwards.',
    'Mandy watches the balloon as it drifts down, to touch the floor...',
  ],
  state:0,
  eventPeriod:1,
  eventIsActive:function() { return player.loc === 'nursery' && this.loc === 'nursery' },
  eventScript:function() {
    if (w.tiny_man.bootsState > 1) w.tiny_man.bootsState++
    if (w.tiny_man.bootsState > 4 && w.tiny_man.bootsState < 10) {
      msg("'Okay, there you go,' says the tiny man, putting the boots on the floor in from of himself. 'Good as new! Well, nearly.'")
      w.tiny_man.bootsState = 10
      w.boots.loc = 'dollshouse'
      w.boots.mended = true
    }

    msg(this.states[this.state])
    this.state++
    if (this.state === this.states.length) {
      msg("Suddenly everything goes white...")
      msg(w.great_gallery.north.msg)
      for (const s of settings.roomTemplate) msg(s)
      this.reset()
      msg(this.states[0])
      this.state++      
    }
  },
  reset:function() {
    this.state = 0
    w.dollshouse.closed = true
    w.dollshouse.hasBeenOpened = false
    w.tiny_man.bootsState = 0
    // reset conv?
    for (const key in w) {
      const o = w[key]
      if (o.room || o.scenery) continue
      if (['nursery', 'dollshouse', 'tiny_man'].includes(o.loc) && !o.player) o.loc = player.name
    }
  },
  examine:"The balloon is bright yellow, and pretty much spherical, except for the bit where it is blown up.",
  take:function() {
    msg("Mandy tries to grab the balloon, but it bounces upwards, out of reach.")
    this.state = 0
  },
  smash:function() {
    msg("Mandy tries to burst the stupid balloon, but it bounces out of reach, rising up to the ceiling.")
    this.state = 0
  },
  burst:function() {
    msg("Mandy jabs at the balloon, and it just bounces off. She jabs again, and then again, and finally the balloon pops! The remains drop to the floor.")
    delete this.loc
    w.yellow_balloon_remains.loc = 'nursery'
  },
})


createItem("yellow_balloon_remains", {
  pronouns:lang.pronouns.plural,
  alias:"remains of a yellow balloon",
  examine:"A ragged piece of yellow rubber.",
  take:'Mandy wonders if the remains of a very annoying balloon are worth picking up. She decides they are not.',
})


createItem("dollshouse", CONTAINER(true), {
  loc:"nursery",
  scenery:true,
  hasBeenOpened:false,
  openCount:0,
  alias:"doll's house",
  synonyms:['dollshouse', 'dollhouse'],
  examine:function() {
    let s = "Like the room, the doll's house is old fashioned. Made of wood, the roof looks like maybe it has been carved to look like it is thatched. The walls are white, the window frames are metal, and it stands on a base painted green. "
    if (this.closed) {
      s += "It looks like the back would open up."
    }
    else {
      s += "The back is opened up, and inside Mandy can see a tiny man."
    }
    msg(s)
  },
  openMsg:function() {
    if (this.hasBeenOpened) {
      msg("She opens the doll's house. There is the little man; he looks at Mandy. 'You again, eh?'")
    }
    else {
      msg("She opens the doll's house. Inside, the house is a perfectly furnished, complete with a little man, sat on a chair.")
      let s = "The little man looks at Mandy, a look of surprise on his face. 'Cor blimey, you're a bigun!' "
      switch (this.openCount) {
        case 0: s += " Apparently he is alive!"; break;
        case 1: s += " Apparently he is alive! Mandy has a strange feeling of déjà vu..."; break;
        case 2: s += " Apparently he is alive! Mandy has a strange feeling of déjà vu, then a feeling of déjà vu about the feeling of déjà vu!"; break;
        case 3: s += " Apparently he is alive! Why is that not a surprise?"; break;
        default: s += " He is alive, just as she expected"; break;
      }
      msg(s)
      this.openCount++
      this.hasBeenOpened = true
    }
  },
})


createItem("tiny_man", NPC(false), {
  loc:"dollshouse",
  scenery:true,
  alias:"tiny man",
  examine:function() {
    let s = "The man is only about ten centimetres tall, but looks normally proportioned. He is dressed in blue overalls, and has dark hair, that is going grey. "
    if (this.state < 10) {
      s += "He seemed to be making a pair of shoes."
    }
    else if (this.state < 20) {
      s += "He is mending the boots Mandy has given him."
    }
    else {
      s += "He is once again making a pair of shoes."
    }
    msg(s)
  },
  bootsState:0,
  msg:function(s, params) { msg(s, params) },  // override default for NPCs so we see it when he is in house
  endFollow:function() {
    msg("'Wait here,' says Mandy to {nm:npc:the}.", {npc:obj})
    return falsemsg("'I wasn't going nowhere!'")
  },
  startFollow:function() {
    msg("'Follow me,' says Mandy to {nm:npc:the}.", {npc:obj})
    return falsemsg("'If it's all the same to you, I'll stay here.'")
  },
  askOptions:[
    {
      name:'Himself',
      test:function(p) { return p.text.match(/himself|who he/) || (p.text.match(/he is/) && p.text2 === 'who')}, 
      msg:"'Who are you?' says Mandy.|He shrugs. 'Name's Cuthbert, but most call me Big Bert.'|'Why do they call you \"Big Bert\"?'|'It's short for Cuthbert, see?'",
    },
    {
      name:'House',
      test:function(p) { return p.text.match(/doll\'?s?\'? ?house/) },
      msg:"'Nice house,' says Mandy politely. 'Is it your?'|'I should be so lucky! I'm just here mending some shoes. They've got so great tools.'",
    },
    {
      name:'Escape',
      test:function(p) { return p.text.match(/escape|way out|get out/) },
      msg:"'I don't suppose you know how I can get out of this stupid house?'|The little man looks around him at the doll's house, then at Mandy. 'You're not in it, love.'|'No, not that house, this one!' She points vaguely around the nursery.|'Wait, I'm in a house inside another house? Stone the crows! If that don't beat all!' Clearly he was not going to be much use in that regard.",
    },
    {
      name:'Shoes',
      test:function(p) { return p.text.match(/shoes/) },
      msg:"'Are you making those shoes or mending them?'|'Mending 'em. Be good as new when I've done with 'em.'",
      script:function() { w.tiny_man.askedAboutShoes = true },
    },
    {
      name:'Mannequins',
      test:function(p) { return p.text.match(/mannequin/) && w.brass_dining_room.visited > 2 },
      msg:"'What's the deal with the mannequins in the dining room?'|The little man look through a doorway, into the dining room of the doll's house. 'Don't see no mannequins in there, love.'",
    },
    {
      name:'Boots',
      test:function(p) { return p.text.match(/boot/) && !w.boots.scenery && w.tiny_man.askedAboutShoes },
      script:function() {
        if (w.boots.loc === player.name) {
          msg("'Could you mend some boots?' Mandy showed him the boots.")
          if (w.boots.size > 4) {
            msg("'Are you kidding me? They're enormous! 'Ow can I get a needle through leather that thick?'")
          }
          else {
            msg("'I should think so. Toss 'em over here, and I'll 'ave a go.'")
            w.tiny_man.bootsState = 1
          }
        }
        else if (w.boots.loc === "tiny_man") {
          msg("'How are you doing with those boots?'|'Nearly done,' he says, not looking up.")
        }
        else {
          msg("'Could you mend boots?' Mandy asks.|He shrugs. 'I guess.'")
        }
      },
    },
    {
      test:function(p) { return p.text.match(/doing/) && p.text2 === 'what' },
      script:function() {
        msg("What are you doing?' asks Mandy")
      },
    },
    {
      script:function(p) {
        msg("Mandy asks the little man about " + p.text + ".")
        msg("'What the..?' he replies, 'Ask me about a topic what I know about.'")
      }
    },
  ],
  afterGive:function(options) {
    if (options.item !== w.boots || w.tiny_man.bootsState !== 1 || w.boots.size !== 4) {
      return falsemsg("Mandy gives {nm:item:the} to the tiny man. 'What'd I want something like that?' he asks.", options)
    }
      
    msg("Mandy gives the boots to the tiny man. 'I'll get on that as soon as I've done these,' he says.")
    msg("Mandy glances at the balloon. 'I don't suppose you could do it now?' She smiles sweetly at him, making him jump back from his seat in horror.") 
    msg("'Okay, okay, giant-lady! Whatever you say!' He drops the shoes, and starts to examine the hole in the boot.")
    w.boots.loc = 'tiny_man'
    w.tiny_man.bootsState = 2
    return true
  },
  talkto:function() {
    msg("Mandy wonders what {i:topics} she could {i:ask the tiny man about}...")
    return false
  }
})


/*
ASK/ABOUT


himself
dollshouse
house
escape/way out
shoes
his past/origin
boots/mending boots




createItem("tinyman_where_live", TOPIC(false), {
  loc:"tiny_man",
  alias:"So where do you live?",
  script:function() {
    msg("'So where {i:do} you live?'");
    msg("'14 Clarence Street. Least, that's where I lived before I come in 'ere.'");
    msg("'Clarence Street? I know that road, Charlene Porter lives there.' It is a terrace house, built in the later nineteenth century, near the centre of town.");
    msg("'I don't know no Charlene. French is she?'");
  },
})


createItem("tinyman_very_small", TOPIC(false), {
  loc:"tiny_man",
  alias:"You are very small",
  script:function() {
    msg("'I can't help noticing...,' says Mandy wondering how she say this, 'that you quite... well, small.'");
    msg("'Or maybe you're freakishly tall.'");
    msg("'Well, maybe. But this room looks to me like a nursery for people my  size, and you're in a toy house.'");
    msg("'Ah, you got me. Yeah, it's me. I'm small. Never used to be; used to tower over me old mum, I does. Then I got trapped in this 'ouse, see. Went exploring, trying to find a way out, like, walked in room, big as normal, came out like this! '");
  },
})


*/
