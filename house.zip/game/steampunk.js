"use strict"



register('steampunk', {
  book:'The Tempest',
  uniform:'a brown uniform, with gold-coloured trim',
  smell:'The house smells old and musty, like it never gets any fresh air at all.',
  listen:'Mandy can hear a quiet humming and rhythmic pounding of distant machinery.',
  floor:"The floor is wooden, and well-polished.",
  walls:"The walls are all panelled in wood.",
  ceiling:"The ceiling is white, with simple decorations along each edge.",
})




createRoom("steam_hall", {
  windowsface:'south',
  in:new Exit('lift', {
    alsoDir:['southeast'],
    msg:'She steps into the lift.',
    simpleUse:function(char) {
      if (w.lift.getTransitDestLocation() !== this.origin) {
        return util.defaultSimpleExitUse(char, new Exit('lift_shaft', {origin:this.origin, dir:this.dir, msg:"She heads through the doorway."}))
      }
      return util.defaultSimpleExitUse(char, this)
    },
  }),
  desc:"This large room is dominated by a huge engine, turning a giant flywheel from two pistons connected to a beam way over Mandy's head. There is a gallery above, accessed via a rather crude lift. As well as going in the lift, there are doors east and west.",
  todo:'Room description needs work.',
  west:new Exit("steam_corridor"),
  east:new Exit("greenhouse_west"),
})




createRoom("lift_shaft", {
  windowsface:'none',
  out:new Exit('steam_hall', { alsoDir:['west', 'northwest']}),
  desc:function() {
    let s = "Mandy is stood at the bottom of a small room, with a high roof - a lift shaft she realises. "
    s += w.lift.getTransitDestLocation() === w.upper_steam_hall ? 
      'The lift itself must be the ceiling of the room, on the floor above.' :
      'The lift itself is way over her head; she can see another doorway above the one she came through that must be the floor above.'
    s += ' There are rails on both side walls, with a rack between them, presumably for a pinion to engage.'
    return s
  },
})




createRoom("steam_corridor", {
  windowsface:'north',
  alias:"A Corridor",
  properNoun:true,
  desc:"The corridor runs from east to west, with three windows along the north side. Various brass pipes run the length of the south wall, while others turn abruptly to dive into the wall on either side of the room. All seem to converge on the east end of the corridor.",
  east:new Exit("steam_hall"),
  west:new Exit("brass_dining_room", {simpleUse:function(char) {
    if (w.brass_dining_room.blocked()) return falsemsg("Mandy starts heading west, but the dining room is now so full of mannequins, she cannot get into it.")
    return util.defaultSimpleExitUse(char, this)
  }}),
  todo:'Room description needs work.',
})

createItem("pipes", {
  loc:"steam_corridor",
  examine:"The pipes are brass, and polished to a shine, though as she looks more closely Mandy can see the more hidden bits are not so well cared for. Some are too hot to touch, others feel very cold.",
})




createRoom("upper_steam_hall", {
  headingAlias:'The Steam Hall (Upper)',
  windowsface:'north',
  desc:"This is a catwalk that overlooks the main steam hall, perhaps to give maintenance access to the upper parts of the great engine. From here, she could go in the lift to get to the upper or lower levels, or head north or east.",
  in:new Exit('lift', {
    alsoDir:['southeast'],
    msg:'She steps into the lift.',
    simpleUse:function(char) {
      if (w.lift.getTransitDestLocation() !== this.origin) {
        msg("Mandy is about to step through the doorway, when she realises there is nothing there! This is, she guesses a lift shaft, minus the lift.")
        return false
      }
      return util.defaultSimpleExitUse(char, this)
    },
  }),
  east:new Exit("greenhouse_catwalk_west"),
  north:new Exit("gallery_south"),
  todo:'Room description needs work.',
})




createRoom("lift", TRANSIT('out'), {
  windowsface:'none',
  desc:"The lift is little more than a cage on vertical rails. Now inside, Mandy can see the mechanism - a motor of some sorts at the back of the lift that turns a cog - or rather a pinion - on a rack.{once: That would mean the weight of the lift is held on just one tooth of the pinion; hmm, perhaps best not to think about that too much.} It is currently at {transitDest:lift}.",
  out:new Exit("steam_control_room", {alsoDir:['west', 'northwest']}),
  testTransit:function(player, options) {
    if (w.Patch.loc !== this.name) return true
    if (this[this.transitDoorDir].name === 'steam_control_room') return true
    if (this[this.transitDoorDir].name === 'upper_steam_hall' && options.button.transitDest !== 'steam_control_room') return true
    if (this[this.transitDoorDir].name === 'steam_hall' && options.button.transitDest === 'steam_hall') return true
    msg("Mandy presses the button for \"{show:item:title}\". The motor shudders and groans, and the lift shakes for a few moments, without actually getting anywhere, before the motor gives up, and falls silent.{once: Mandy looks at Patch, and wonders how much he weighs...}", {item:options.button})
    return false
  },
})
const liftDests = ['steam_hall', 'upper_steam_hall', 'steam_control_room']
const liftDestNames = ['Steam Hall', 'Upper Steam Hall', "Control Room"]
const seeFromFloras = ['at the bottom', 'in the middle', 'at the top']
for (let i = liftDests.length-1; i >= 0; i--) {
  createItem("button_" + (i+1), TRANSIT_BUTTON("lift"), {
    alias:"Button: " + (i+1) + ' (' + liftDestNames[i] + ')',
    examine:"A button with the number " + (i+1) + " on it.",
    transitDest:liftDests[i],
    title:'Floor ' + (i+1) + ': ' + liftDestNames[i],
    seeFromFlora:seeFromFloras[i],
    scenery:true,
    transitAlreadyHere:"Mandy presses the button marked " + (i+1) + "; nothing happens. Perhaps the lift is already there?",
    transitGoToDest:"Mandy presses the button marked " + (i+1) + "; the cage door closes and with a judder, the motor on the floor of the lift comes to life. A few moments later she is at the " + liftDestNames[i] + " floor.",
  })
}






createRoom("steam_control_room", {
  alias:"control room",
  windowsface:'none',
  north:new Exit("weird_room"),
  in:new Exit('lift', {
    alsoDir:['southeast'],
    msg:'She steps into the lift.',
  }),
  desc:"The control room... A doorway to the southeast goes back to the lift.{if:invite:scenery: There is a wedding invitation on the desk.}",
  afterFirstEnter:function() {
    msg("'Good day, miss,' says the man. 'I'm Malewicz; Dr Winfield Malewicz. It's such a delight to actually meet someone after all this time.' This is the guy the letter is for, Mandy realises.")
  },
  afterEnter:function() {
    if (w.Winfield_Malewicz.loc === this.name) return
    w.Winfield_Malewicz.loc = this.name
    msg("Dr Malewicz follows Mandy into the strange room.") 
  },
  todo:'Room description needs work.',
})

createItem("Winfield_Malewicz", NPC(), {
  loc:"steam_control_room",
  songlist:[],
  endFollow:function() {
    msg("'Wait here,' says Mandy to {nm:npc:the}.", {npc:obj})
    return falsemsg("'I wasn't going anywhere!'")
  },
  startFollow:function() {
    msg("'Follow me,' says Mandy to {nm:npc:the}.", {npc:obj})
    return falsemsg("'I doubt the house will let me. It has kept me here a very long time.'")
  },
  talkto:function() {
    msg("Mandy wonders what {i:topics} she could {i:ask Dr Malewicz about}...")
    return false
  },
  afterGive:function(options) {
    if (options.item !== w.letter) {
      return falsemsg("Mandy offer {nm:item:the} to Dr Malewicz, who looks at it with disdain. 'what's that for?' he asks.", options)
    }
      
    msg("Mandy gives the letter to Dr Malewicz 'This is for you; it was in the street.'")
    msg("'A letter?' He turns it over, inspecting the address. 'It is for me! This is most unusual.'") 
    msg("'I know, right? Who sends letters nowadays?'")
    msg("Malewicz proceeds to open the envelope, and eagerly pulls out the letter. 'A wedding invitation! How delightful!' He thinks for a moment. 'What's the date?'")
    msg("'Thirteenth of May.... Er, 2016.'")
    msg("'Oh, it seems I have missed it then. And the centenary, if it comes to that. How disappointing.' He thows the envelope away, but put the invation on the desk. 'He was married back in 1903, but I was aware it was not a happy marriage. His new wife is, I think his cousin. I hope they'll be happy. Or were happy, I should say.'")
    delete w.letter.loc
    w.invite.loc = 'steam_control_room'
    w.invite.scenery = true
    return true
  },
  askOptions:[
    {
      name:'Himself',
      test:function(p) { return p.text.match(/himself|who he/) || (p.text.match(/he is/) && p.text2 === 'who')},
      script:function() {
        msg:"'Who are you?' says Mandy.|'I'm Dr Winfield Malewicz, inventor and natural philosopher. I came to England from Poland in 1895, intending to study the very nature of space and time. I read a very promising thesis by a promising student of Prof. Alfred Kleiner, and that led to me to certain experiments that, in hindsight, were a little ill-advised. Might I ask who you are?",
        msg("'I'm Amanda Kettleton, but everyone calls me Mandy. I was just passing the house... and I kind of got trapped here.'");
        msg("'{class:riddle:Story of my life!} This is my house once,' he says. 'I built the analytical machine you see before you. Now, well, I think it belongs to itself now. You can talk to it, you know. Only thing that keeps me sane, oh the {class:riddle:midnight memories} we've shared.' Mandy is not entirely convinced it has kept him sane.");
        w.Winfield_Malewicz.songlist.push("Midnight memories")
        w.Winfield_Malewicz.songlist.push("Story of my life")
      }
    },
    {
      name:'What happened',
      test:function(p) { return p.text.match(/what happened|house/) || (p.text.match(/happen/) && p.text2 === 'what')}, 
      script:function() {
        if (!currentLocation === w.lounge) {
          msg("'What... happened?'")
          msg("'It came alive. The house, that is. My fault really. I suppose there really are things that man should not mess with.'");
          msg("'Bullshit. What about iPods and Facebook and XBox; where would they be if mankind took that attitude?'");
          msg("'I... have no idea what you are talking about.'");
          msg("'No, you don't, which is kind the point really. So just tell me what happened.'");
          msg("'It got sick. The silvers, I don't know where they came from, but they infected it like a virus. They wanted to infect other houses, {class:riddle:more than this} one.");
          w.Winfield_Malewicz.whatHappenedAsked = true
          w.Winfield_Malewicz.songlist.push("More than this")
        }
        else if (w.Winfield_Malewicz.whatHappenedAsked) {
          msg("'And again, what happened?'")
          msg("'I must confess I am not entirely certain. It is as though there were two minds at work; the evil house being dominant, but the good house that we briefly saw was good and trying to help us. It was the good house that posed the riddle, knowing the answer would end it all, and somehow tricked the evil house into asking it.'")
          msg("'And the answer?'")
          msg("'Obvious in hindsight' said Dr Malewicz, 'Pass though time and space in one direction,  in a linear, orderly manner. But why you?'")
          msg("Mandy shrugged. 'I was into a boy-band called One Direction.'")
        }
        else {
          msg("'What... happened?'")
          msg("'It came alive. The house, that is. My fault really. I suppose there really are things that man should not mess with.'");
          msg("'Bullshit. What about iPods and Facebook and XBox; where would they be if mankind took that attitude?'");
          msg("He looks at Mandy in confusion for a moment, before continuing. 'I must confess I am not entirely certain, but it appears there were two minds at work; the evil house being dominant, but the good house that we briefly saw was good and trying to help us. It was the good house that posed the riddle, knowing the answer would end it all, and somehow tricked the evil house into asking it.'")
          msg("'And the answer?'")
          msg("'Obvious in hindsight' said Dr Malewicz, 'Pass though time and space in one direction,  in a linear, orderly manner. But why you?'")
          msg("Mandy shrugged. 'I was into a boy-band called One Direction.'")
        }
      } 
    },
    {
      name:'Silvers',
      test:function(p) { return p.text.match(/silver/) },
      script:function() {
        msg("'What's the deal with the silver figures?'");
        msg("'They seem to be behind all this. I can't decide if it is deliberate - a plan devised by intelligent agents - or they are just pests, like dimensional termites, mindlessly wreaking destruction. I'm rather afraid they got here because of me though.'");
      }
    },
    {
      name:'Path',
      test:function(p) { return p.text.match(/patch/) },
      script:function() {
        msg("'What's the deal with Patch?'");
        msg("'Patch?' Dr Malewicz looks confused.");
        msg("'The corpse you were tring to animate with lightning.'");
        msg("'I can assure that that is nothing to do with me. Yes, I had seen it. Rather gruesome, I thought. As though lightning can animate a body; quite the reverse in fact! It tends to be fatal.'");
      }
    },
    {
      name:'Song Titles',
      test:function(p) { return p.text.match(/song/) && currentLocation === w.lounge && w.Winfield_Malewicz.songlist.length > 0 },
      script:function() {
        msg("'So how did you know those One D song titles?'");
        msg("'I'm not sure what you're talking about.'");
        let s = "'You were dropping me clues. "
        s += formatList(w.Winfield_Malewicz.songlist.map(el => "{i:" + el + "}"), {lastJoiner:'and'})
        s += ". They're all One Direction song titles.'"
        msg("'I still don't know what you are talk about.'")
      }
    },
    {
      name:'Riddle',
      test:function(p) { return p.text.match(/riddle|question/) && w.weird_room.visited > 0 },
      script:function() {
        msg("'It keeps asking the same question. What direction?'");
        msg("'I'm sorry, I can't help you. I rather think it's {class:riddle:gotta be you}, you see. You have to solve this {class:riddle:one thing}.'");
        msg("'But I don't know what to do!'");
        msg("'Well, you have to do it, {class:riddle:one way or another}. Otherwise {class:riddle:you and I} are here for a very long time.'");
        w.Winfield_Malewicz.songlist.push("One way or another")
        w.Winfield_Malewicz.songlist.push("You and I")
        w.Winfield_Malewicz.songlist.push("Gotta be you")
        w.Winfield_Malewicz.songlist.push("One thing")
      }
    },
    {
      name:'How long here',
      test:function(p) { return p.text.match(/what happened/) || (p.text.match(/long/) && p.text.match(/here/) && p.text2 === 'how')}, 
      script:function() {
        msg("'How long have you been here?'");
        msg("'A long time. It feels like several years, but I suspect considerably longer have passed on the outside. Your mode of dress looks quite alien to me, for {class:riddle:one thing}; the colours are garnish, the thread I cannot guess at. {class:riddle:More than this}, your hemline is, well, it would be considered scandalous in 1911. And yet I suppose they are common in your time?'");
        msg("Mandy glanced down at her uniform, now inexplicably red and hot pink. 'I was wearing grey and navy when I entered the house. But yeah, its 2016.'");
        msg("'Over a hundred years...'");

        w.Winfield_Malewicz.songlist.push("One thing")
        w.Winfield_Malewicz.songlist.push("More than this")
      }
    },
    {
      name:'Escape',
      test:function(p) { return p.text.match(/escape|way out|get out/) },
      script:function() {
        msg("'Is there no way out?'");
        msg("'None. The walls might as well be made of {class:riddle:steel, my girl}.'");
        w.Winfield_Malewicz.songlist.push("Steal my girl")
      }
    },
    {
      name:'Silvers',
      test:function(p) { return p.text.match(/silver/) },
      script:function() {
        msg("'What are the silver figures I keep seeing?'")
        msg("'Entities from another dimension. I think they slipped through when he house... changed. They're worse after dark - the {class:riddle:night changes} things around here; they'll try to {class:riddle:drag me down} to their lair. So far, I have managed to repel them.'")
        w.Winfield_Malewicz.songlist.push("Night changes")
        w.Winfield_Malewicz.songlist.push("Drag me down")
      }
    },
    {
      name:'Einstein',
      test:function(p) { return p.text.match(/einstein/) && w.invite.hasBeenRead },
      script:function() {
        msg("'So, er, you know Einstein?'")
        msg("'What makes you say that?'")
        msg("'Er...' She does not want him to know she read the invite. 'This seems like the sort of stuff he would be into.'")
        msg("'You're familiar with his work? I always suspected his research would go down in {class:riddle:history}.'")
        msg("'Sure. Relativity and... that... stuff.'")
        w.Winfield_Malewicz.songlist.push("History")
      }
    },
    {
      name:'Relativity',
      test:function(p) { return p.text.match(/relativity/) && w.invite.hasBeenRead },
      script:function() {
        msg("'I guess you know all about relativity?'She had to admit she had not paid that much attention in physics, but she was fairly sure that had not been on the syllabus.")
        msg("'I'm not exactly an expert. I'm what you might call a practical scientist, rather than theoretical. I'm afraid soe of the maths is beyond me.'")
        msg("'Oh, God, yes!' says Mandy with feeling. If even Dr Malewicz struggles with maths, she does not feel so bad about doing so too.")
        msg("'The basic principle is that if you are no a train and it is a perfectly smooth ride, there is no way to tell if you are moving or stationary without looking outside, and therefore it is equally valid to say the train is stationary and the world is moving as it is to say the train is moving.'")
        msg("'That's all there is too it?'")
        msg("'Well, that's the starting point.'")
      }
    },
    {
      script:function(p) {
        msg("Mandy asks Dr Malewicz about " + p.text + ".")
        msg("'I'm sorry my dear,' he replies, 'I have no idea what you're talking about. Is there some other topic you'd like to discuss?'")
      }
    },
  ],
})


/*
himself
house
escape/way out
what happened/history

*/


/*

createItem("wm_1911", TOPIC(false), {
  loc:"Winfield_Malewicz",
  alias:"You have been here since 1911?",
  script:function() {
    msg("'You have been here since 1911?'");
    msg("'The King is due to have his Delhi Durbar in a few weeks.'");
    msg("'Er, which king is that?'");
    msg("'George V. I suppose he is just {class:riddle:history} to you. Who's king now?'");
    msg("'Queen. Queen Elizabeth II.'");
    msg("'A queen? Jolly good. England became great under Queen Victoria.'");

    w.Winfield_Malewicz.songlist.push("History")
  },
})
*/

createItem("invite", {
  alias:"Wedding Invitation",
  synonyms:['invite', 'letter'],
  examine:"The wedding invitation is printed in black, on off-white card, with very ornate handwriting. Mandy wonders if she dares to read it...",
  read:function() {
    msg("Mandy tries to casually read the invitation without appearing to...\"My very good friend and his companion are cordially invited to the wedding of Albert Einstein to Elsa Löwenthal, on the Second of June, 1919, at the Oranienbergerstrasse Synagogue in Berlin.\" Wait, {i:the} Albert Einstein?")
    this.hasBeenRead = true
  }
})


createItem("analytical_engine", {
  scenery:true,
  loc:"steam_control_room",
  alias:"Analytical Engine",
})







createRoom("weird_room", {
  alias:"A Weird Room",
  properNoun:true,
  windowsface:'none',
  south:new Exit("steam_control_room"),
  afterFirstEnter:function() {
    msg("She glances at it quickly, the windows that seem to be laughing at her. How was that even possible? There are four windows, all rectangular and all different sizes. They look nothing like eyes, and yet somehow she knows they are laughing at her. {i:No, that's was wrong,} she says to herself. {i:They're not windows, they really are eyes, and there's only two of them!}")
    msg("'A mere girl,' says the house... No, says the {i:man}, Mandy tells herself. 'A mere girl thinks she can solve a riddle that has stumped poor Malewicz for over a century?'")
    msg("'Over a century?' says Dr Malewicz. 'Can it really be that long?'")
    msg("'Actually I never claimed to be able to solve anything,' Mandy pointed out. 'So if you could let me out, I'll just be on my way..?'")
    msg("'{smallcaps:No one leaves the house!}' the man shouts. Then, in a quieter, but no more pleasant voice; 'It's just not possible. Now, that riddle... would you like to hear it.'")
    msg("Mandy shrugs. 'I guess.'")
    msg("'What direction?'")
    msg("'That's it? What sort of riddle is that? That's as lame as \"what have I got in my pocket?\"'")
    msg("'Fiendishly tricky.'")
    msg("'Lame.'")
    msg("'Nevertheless, you will not leave until you solve it.'")
  },
  afterEnter:function() {
    w.Winfield_Malewicz.loc = this.name
    msg("Dr Malewicz follows Mandy into the strange room.") 
  },
  todo:'Room description needs work.',
})

createItem("house_man", NPC(), {
  loc:"weird_room",
  endFollow:function() {
    msg("'Wait here,' says Mandy to {nm:npc:the}.", {npc:obj})
    if (!this.leaderName) return falsemsg("")
    obj.setLeader()
    msg("")
    return true
  },
  startFollow:function() {
    msg("'Follow me,' says Mandy to {nm:npc:the}.", {npc:obj})
    if (this.leaderName) return falsemsg("")
    obj.setLeader(player)
    msg("")
    return true
  },
  talkto:function() {
    msg:"'What...' Mandy starts to say.",
    msg("'Uh-uh-uh, says the man. Or the house. 'Not until you answer my question. What direction?'");
    msg("Mandy wonders what she should say.")
    return false
  },
  askOptions:[
    {
      test:function(p) { return true },
      script:function(p) {
        msg:"'What...' Mandy starts to say.",
        msg("'Uh-uh-uh, says the man. Or the house. 'Not until you answer my question. What direction?'");
        msg("Mandy wonders what she should say.")
      }
    },
  ],
})