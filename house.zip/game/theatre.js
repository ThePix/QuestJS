"use strict"



register('theatre', {
  book:'Twelfth Night',
  uniform:'a long, dark green dress, with ridiculous white ruffs at the cuffs and collar',
  smell:'There is an odd smell here; it reminds Mandy of hot asphalt, but not quite the same.',
  listen:'Mandy listens... Is that applause she hear faintly here?',
  floor:"The floor is wooden, and a little worn. Well-trodden, even.",
  walls:"The walls are a dirty cream colour; the paint is peeling in places.",
  ceiling:"The ceiling is white.",
})








createRoom("theatre", {
  windowsface:'none',
  alias:"theatre backstage",
  properNoun:true,
  desc:"This is a long, narrow room full of junk -- what looks like old stage scenery and props. It looks as though the exits northwest and southwest lead to the stage, whilst east heads back to the gallery.",
  afterEnter:function() {
  },
  northwest:new Exit("theatre_stage", {msg:'Mandy heads northwest, through the side-left wing, onto the stage.'}),
  southwest:new Exit("theatre_stage", {msg:'Mandy heads southwest, through the side-right wing, onto the stage.'}),
  east:new Exit("gallery_south"),
  scenery:[
    {alias:'scenery', examine:'There are several huge boards, each painted on both sides, presumably designed to go together to form either a country lane backdrop, or, when reversed, a room with panelled walls.'},
    {alias:['junk', 'props'], examine:'There is a table that is upside-down, with two chairs, a grandfather clock and a hatstand on it.'},
    {alias:'table', examine:'The table is wooden, and quite plain.'},
    {alias:'chairs', examine:'The chairs are made of dark wood, and are ornate, if rather shabby.'},
    {alias:'hatstand', examine:'The hatstand is wooden, and badly made; it is a wonder it is still together.'},
    {alias:'grandfather clock', examine:'On closer inspection the grandfather clock is actually a tall, narrow box, painted to look like a clock.'},
  ],
})




createRoom("theatre_stage", {
  windowsface:'none',
  alias:"theatre stage",
  desc:"{once:They say \"All the world's a stage\", but this bit definitely is, muses Mandy, realising she is indeed standing on a stage:Mandy is standing on a stage}. The curtain is up and bright lights are pointed at her, making it hard to see the rest of the theatre, but the chairs seem to be empty. As theatres go, it is not big, with a small balcony, and only a dozen or so rows in the stalls. Backstage is through the wings, northeast and southeast",
  beforeFirstEnter:function() {
    msg("'Oh, what? Hey!' She is startled for a moment to see a figure standing on the stage. She is about to say something more articulate when she realises it is not moving.")
    w.clockwork_thespian.loc = this.name
  },
  west:new Exit("_", {use:util.cannotUse, msg:'Mandy heads west, towards the edge of the stage, intending to jump down into the stalls, but somehow cannot do it. As she gets nearer to the edge her steps get heavier and heavier -- it is almost like those bright lights are pushing her back.'}),
  northeast:new Exit("theatre", {msg:'Mandy heads northeast, through the side-left wing, to the backstage area.'}),
  southeast:new Exit("theatre", {msg:'Mandy heads southeast, through the side-right wing, to the backstage area.'}),
  scenery:[
    {alias:'lights', examine:'There are about a dozen lights shining directly on to the stage, from three points up on the ceiling. They are too bright for her to see anything behind them.'},
    {alias:'orchestra pit', examine:'Curiously, there is no orchestra pit.'},
    {alias:['seats', 'audience', 'rows'], examine:'Mandy scans the threatre again. There are perhaps three hundred seats, and they all seem to be empty.'},
    {alias:['balcony', 'gods'], examine:'The balcony looks to have three rows of seats.'},
    {alias:'stalls', examine:'There are about twelve rows of seats in the stalls.'},
    {alias:'curtain', examine:'Above her head, Mandy can see the red curtain.'},
    {alias:'box', examine:'There is no box on either side, Mandy notes.'},
    {alias:['scenery','backdrop'], examine:'The backdrop is just a wall with three large{if:generic_window:bricked_up:, bricked-up} windows.'},
  ],
    
    
})

createItem("clockwork_thespian", NPC(), CONTAINER(false), {
  alias:"theatre mannequin",
  synonyms:['theatre mannequin', 'clockwork thespian'],
  state:0,
  testDropIn(options) {
    if (options.item !== w.large_key) return falsemsg("That is not something you can put in the keyhole. The clue is in the word \"keyhole\".")
    if (w.large_key.size > 6) return falsemsg("The key is too large for the keyhole.")
    if (w.large_key.size < 6) return falsemsg("The key is too small for the keyhole.")
    return true
  },
  getAgreement:function() {
    return falsemsg("'I have no time for that, girl! I have a show to prepare!'")
  },
  brevity:function() {
      msg("'I've found it, the answer,' says Mandy triumphantly. 'It's \"Brevity\"!'")
      msg("'{class:riddle:Perfect!} Indeed it is. I knew you would find it. And now I will tell you how to escape this house. Outside this small theatre is a long gallery, with a chess set on a table.'")
      if (w.chess_pieces.gluedDownNoted) {
        msg("'I saw it. All the pieces are glued down.'")
        msg("'Not all of them. The white k{class:riddle:night changes} the room if you twist it, takes you outside the house.'")
      }
      else {
        msg("'I saw it.'")
        msg("'The white k{class:riddle:night changes} the room if you twist it, takes you outside the house.'")
      }
      w.white_knight.active = true
      w.clockwork_thespian.state = 102
  },
  examine:function() {
    if (w.clockwork_thespian.state === 0) {
      msg("The figure seems to have been manufactured to resemble a man of impressive proportions, in height, but also in the girth of his chest. And its groin too, Mandy notices with a wry smile. It, or he, is constructed of brass, and looks to be jointed. He is clothed in a frilly off-white shirt, and dark baggy trousers, as well as a floppy hat. Mandy notices there is a hole in the back of his shirt, and a corresponding hole in his back, where a simple, if large, key might fit.")
    }
    else {
      msg("The clockwork thespian seems to have been manufactured to resemble a man of impressive proportions, in height, but also in the girth of his chest. And his groin too, Mandy noticed with a wry smile. He is constructed of brass, and looks to be jointed. He is clothed in a frilly off-white shirt, and dark baggy trousers, as well as a floppy hat.")
    }
  },
  talkto:function() {
    if (w.clockwork_thespian.state === 0) {
      msg("'Hello!' says Mandy to the inanimate figure. There is no response.")
    }
    else if (w.clockwork_thespian.state === 1) {
      msg("'So...' says Mandy, 'I don't suppose you can tell me how to get out of here?'")
      msg("'I seek to know what the soul of wit is. If you can tell me what that is, then I shall help you as far as I am able.'")
      msg("'The soul of wit? I've no idea what you're talking about.'")
      msg("'Come, come, it is a simple question. Any scholar of the bard should know it. You have one of his works in your bag. I must say, Twelfth Night is one of my favourites. Why do you feign ignorance?'")
      msg("{i:No feigning here,} thinks Mandy. The bard, that has to be Shakespeare. She wishes she had actually read some of that stupid book. {if:shakespeare_book:state:0:Wait, did he say \"Twelfth Night\", that is not right. Her book is \"Antony and Cleopatra\". She has a feeling he wrote quite a few plays:Then again, she has a feeling he wrote quite a few plays}. 'So, remind me which play it was again.'")
      msg("'Why, Hamlet of course, as you well know. Act 2, scene 2. Now quickly girl, answer the question, and we shall be done here.'")
      w.clockwork_thespian.state = 2
    }
    else if (w.clockwork_thespian.state === 2) {
      msg("'Why do you need to know what the soul of wit is anyway?'")
      msg("'There are rules that must be obeyed. If I am to help you, then you must first do something for me. As to the exact question, well, I made that up myself. You are clearly a scholar of the bard, so I know it is easy for you, but for the riff-raff, it will be utterly beyond them.'")
      w.clockwork_thespian.state = 3
    }
    else if (w.clockwork_thespian.state === 3) {
      msg("'How do you know what's in my bag?'")
      msg("'I just do. It is something you get use to when you've been here as long as I have. One might as well ask, how does one remember one's name. One just does.'")
      msg("'How long have you been here?'")
      msg("'I don't really know, it is so hard to judge. It was the 3rd of October 1932 when I entered herein. To me, it feels as though at least two or three whole years have passed.'")
      w.clockwork_thespian.state = 4
    }
    else if (w.clockwork_thespian.state === 4) {
      msg("'I'm not really a, er, scholar of the bard.'")
      msg("'Ah, such modesty. So becoming in a young lady!'")
      msg("'No, really. I know fuck all about Shakespeare, and I'm not much of a lady either!'")
      msg("'Oh. Oh, dear. That's unfortunate. I'm afraid once the question has been set, it cannot be unset.'")
      msg("'Says who? Who makes up these stupid rules?'")
      msg("He shrugged. 'That's just the way things are in The House. Perhaps you should look it up? In a library, maybe. I imagine there's a library...'")
      w.clockwork_thespian.state = 5
    }
    else if (w.clockwork_thespian.state === 5) {
      msg("Mandy had nothing to say to the Clockwork Thespian at the moment.")
    }
    else if (w.clockwork_thespian.state === 101) {
      w.clockwork_thespian.brevity()
    }
    else if (w.clockwork_thespian.state === 102) {
      msg("Mandy has nothing to say to the Clockwork Thespian at the moment.")
    }
    else if (w.clockwork_thespian.state === 201) {
      msg("'What the fuck?' says Mandy to the Clockwork Thespian indignantly. 'You said I'd be able to get out of this stupid house!'")
      msg("'And indeed you did!'")
      msg("'I want to go home, you stupid jerk, not to some field full of dead people.'")
      msg("'Of course, but it is a process. Going to the battlefield was a necessary part of that process.'")
      msg("'Seriously?' pouts Mandy. 'So what's the next part of this stupid process then?'")
      msg("'I would suggest there was something at the battlefield that will help you progress.'")
      msg("'The oar? I hadhad that, but it did not come back with me.'")
      msg("'Something else. Something that may help the passing of time...'")
      msg("'What the..?'")
      msg("'I can say no more.'")
      msg("'Of course not! Heaven forbid you could just tell me!'")
      w.clockwork_thespian.state = 202
    }
    else if (w.clockwork_thespian.state === 202) {
      msg("Mandy has nothing to say to the Clockwork Thespian at the moment; she just gives the stupid thing a kick.")
    }
  },
  windup:function() {
    if (w.large_key.loc !== player.name && w.large_key.loc !== this.name)  {
      return falsemsg("Mandy has nothing to wind up the mannequin with.")
    }
    else {
      return this.dowindup()
    }
  },
  dowindup:function() {
    if (w.large_key.size < 6) {
      return falsemsg("Mandy looks at the hole in the back of the inanimate figure; a square peg. Like it would fit the key she has -- only much much bigger.")
    }
    if (w.large_key.size > 6) {
      return falsemsg("Mandy looks at the hole in the back of the inanimate figure; a square peg. Like it would fit the key she has -- if not {i:that} big.")
    }
    
    if (w.clockwork_thespian.state === 0) {
      msg("Mandy looks at the hole in the back of the inanimate figure; a square peg. She puts the large key over it, and finds it is a good fit. What are the odds? She gives it half a turn, with some effort. Another turn, and another, until it will turn no more.")
      msg("Suddenly, the figure moves, and Mandy jumps back, even though that is exactly what she is hoping for. He looks at her. 'Good day. I see you are a fellow thespian!' in a fruity voice.")
      this.state = 1
      this.setAlias('clockwork thespian')
    }
    else {
      msg("Mandy gives the clockwork thespian another couple of turns with the key. She does not want him winding down.")
    }
    return true
  },
  nameModifierFunction:function(list) {
    if (list.length === 2) list.shift() // A hack!!!
  },

  askOptions:[
    {
      test:function(p) { return p.text.match(/escape|house/) },
      script:function(p) {
        msg("'So...' says Mandy, 'I don't suppose you can tell me how to get out of here?'")
        msg("'I seek to know what the soul of wit is. If you can tell me what that is, then I shall help you as far as I am able.'")
        msg("'The soul of wit? I've no idea what you're talking about.'")
        msg("'Come, come, it is a simple question. Any scholar of the bard should know it. You have one of his works in your bag. I must say, Twelfth Night is one of my favourites. Why do you feign ignorance?'")
        msg("{i:No feigning here,} thinks Mandy. The bard, that has to be Shakespeare. She wishes she had actually read some of that stupid book. {if:shakespeare_book:state:0:Wait, did he say \"Twelfth Night\", that is not right. Her book is \"Antony and Cleopatra\". She has a feeling he wrote quite a few plays:Then again, she has a feeling he wrote quite a few plays}. 'So, remind me which play it was again.'")
        msg("'Why, Hamlet of course, as you well know. Act 2, scene 2. Now quickly girl, answer the question, and we shall be done here.'")
        w.clockwork_thespian.state = 2
      }
    },
    {
      test:function(p) { return p.text.match(/wit/) },
      script:function(p) {
        msg("'So... the soul of wit, the soul of wit... What was that again?' asks Mandy.")
        msg("'That is for you to determine, my dear,' declares the clockwork thespian. 'Tis a simple question.'")
      }
    },
    {
      test:function(p) { return p.text.match(/cock|dick|penis/) },
      script:function(p) {
        msg("What would a clockwork thespian have... down below, Mandy muses. Anything at all? She is tempted to ask him, but it might be a sensitive subject, and really none of her business.")
      }
    },
    {
      test:function(p) { return p.text.match(/theatre/) },
      script:function(p) {
        msg("'What's the deal with the theatre?' asks Mandy. 'Are there ever shows?'")
        msg("'Also no,' laments the clockwork thespian. 'The lights are on, but no audience awaits in rapt anticipation, no actors perform.'")
      }
    },
    {
      test:function(p) { return p.text.match(/shakespeare/) },
      script:function(p) {
        msg("'Tell me about Shakespeare,' says Mandy. 'What was he like?'")
        msg("'I can assure you, I am not that old!' declares the clockwork thespian.")
      }
    },
    {
      test:function(p) { return true },
      script:function(p) {
        msg("'Tell me about " + p.text + "' says Mandy.")
        msg("'I'm sure I don't know about that!' declares the clockwork thespian.")
      }
    },
  ],
  tellOptions:[
    {
      test:function(p) { return true },
      script:function(p) {
        msg("Mandy starts to tell the clockwork thespian about " + p.text + " but he pays no attention.")
      }
    },
  ],
})
