"use strict"

settings.title = "The House on Highfield Lane"
settings.author = "The Pixie"
settings.version = "0.1.4"
settings.thanks = []
settings.warnings = "Occasional bad language, including the F-word."
settings.playMode = "beta"
settings.transcript = 'test'
settings.getDefaultRoomHeading = function(item) { return titleCase(lang.addDefiniteArticle(item) + item.alias) }

settings.symbolsForCompass = true
settings.panes = settings.playMode === "dev" ? 'left' : 'none'
settings.themes = ['serif']
settings.favicon = 'assets/icons/houseicon.png'

settings.ifid = "8F79966F-54C6-4DA3-842A-330DBA5D0CB0"


settings.files = [
  'code', 'data', 'external', 'normality',
  'victorian', 'battlefield', 'flora', 'medieval', 'steampunk', 'theatre',
  //'hints',
]
settings.tests = true
settings.styleFile = 'style'

settings.noAskTell = false
settings.givePlayerAskTellMsg = false

settings.roomTemplate = [
  "#{cap:{hereName}}",
  "{terse:{hereDesc}}",
  "{objectsHere:She can see {objects} here.}",
  "{ifNot:settings:playMode:play:{ifExists:currentLocation:todo:{class:todo:{show:currentLocation:todo}}}}",
]

settings.fluids = ['sand', 'water']

settings.roomCreateFunc = function(o) {
  o.zone = zone
}

settings.afterLoadc = function() {
  parser.pronouns = {}
}

settings.statsData = [
  {name:'Objects', test:function(o) { return true }},
  {name:'Locations', test:function(o) { return o.room }},
  {name:'Locations requiring work', test:function(o) { return o.room && o.todo !== undefined }},
  {name:'Items', test:function(o) { return !o.room }},
  {name:'Takeables', test:function(o) { return o.takeable }},
  {name:'Scenery', test:function(o) { return o.scenery }},
  {name:'NPCs', test:function(o) { return o.npc && !o.player }},
]

settings.intro = "There is something weird about the house on Highfield Lane. Whenever she walks past it, Mandy feels a chill, and hurries to be away from it. It is not the only house on Highfield Lane, there are a couple of dozen, all built in the late nineteenth century, but to Mandy it is {i:the} house. The end of the row, on the right, as she walks up the hill, before the town gives way to fields.|Tuesday... exams in three weeks, so tonight will be another evening of devising evermore complex and artistic revision timetables. Perhaps she should get down to some real revision, maybe biology or French. She should really learn those irregular verbs. Her bag slips off her shoulder, and she shivers, suddenly feeling cold; she is already at that house. Usually she would have crossed over to the other side of the road to avoid it by now. She glances at it quickly, the windows that seem to be laughing at her. How was that even possible? There are four windows, all rectangular and all different sizes. They look nothing like eyes, and yet somehow she knows they are laughing at her."

settings.blurb = [
  'The house at the top of Highfield Lane has always scared Mandy, though she could never say why exactly. Perhaps today is the day she should confront that fear!',
  'I started writing this in 2012-13, and to be honest bits of it were more relevant back then. Like why has Mandy not got a mask in her bag? For the record, then, this is set in 2016.',
  'There are a couple of riddles... The first is for Mandy to solve, the second for you. YOU may know the answer to the first, and if you do not you can easily Google it. Good for you. The riddle is for Mandy, and to solve it you need to find a way for HER to look it up. The second riddle, however, is for YOU, and you need to connect the numerous - if obscure - clues throughout the game to solve it and complete the game.',
  'While every item is there for a reason, some of them are just to help create a world, and not because you need to use them to progress, such as the items in your inventory at the start, maybe?',
  'WARNING: There is occasional swearing, including the F-word.',
]

settings.betaBlurb = [
  'Hi, I am looking for beta-testers for a game for IFComp. It is, I guess, a fairly traditional parser game, complete with puzzles (though written in third person), though would be rated "merciful" on the cruelty scale. It is one of the first games made with Quest 6, aka QuestJS, so is entirely in JavaScript and will run in the browser. The plot revolves around trying to escape a house that is - to a degree - warped in time and space.',
  'I would like to have around six testers, with two new testers at each version with a fresh pair of eyes. Grammar Nazis welcome!',
]

settings.setup = function() {
  for (const s in w.shakespeare_book.names) w.shakespeare_book.synonyms.push(w.shakespeare_book.names[s])
}