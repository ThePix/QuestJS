"use strict";

//Generic class for skills; you should not use directly
class Skill {
  constructor(name, data) {
    this.name = name
    this.offensiveBonus = 0
    for (let key in data) this[key] = data[key]
    if (!this.alias) this.alias = name
    //log(this.alias)
    if (data.effect) {
      new Effect(this.name, this.effect, data)
      this.targetEffectName = true
    }
    if (rpg.findSkill(this.name, true)) throw new Error("Skill name collision: " + this.name)
    rpg.list.push(this)
  }



  testUseable(char) { return rpg.defaultSkillTestUseable(char) }
  afterUse(attack, count) { rpg.defaultSkillAfterUse(attack, count) }

}


// All attacks are divided between spells, weapon attacks and natural attacks
// If you need to usae a weapon, it is a weapon attack
// If you need to learn a spell first, it is a spell
// Otherwise, it is a natural attack

class WeaponAttack extends Skill {
  constructor(name, data) {
    super(name, data)
    this.msgAttack = lang.attacking
    this.statForOffensiveBonus = 'offensiveBonus'
  }
  testUseable(char) { return true }
  afterUse(attack, count) { }
}


class NaturalAttack extends Skill {
  constructor(name, data) {
    super(name, data)
    this.noWeapon = true
    this.msgAttack = lang.attacking
    this.statForOffensiveBonus = 'offensiveBonus'
  }
  testUseable(char) { return true }
  afterUse(attack, count) { }
}


class Spell extends Skill {
  constructor(name, data) {
    super(name, data)
    this.spell = true
    this.noWeapon = true
    this.msgAttack = lang.castSpell
    this.statForOffensiveBonus = 'spellCasting'
  }
  testUseable(char) { return rpg.defaultSpellTestUseable(char) }
  afterUse(attack, count) {  rpg.defaultSpellAfterUse(attack, count) }
}

class SpellSelf extends Spell {
  constructor(name, data) {
    super(name, data)
    this.getPrimaryTargets = function(target, attack) { 
      return [attack.attacker]
    }
    this.noTarget = true
    this.suppressAntagonise = true
    this.automaticSuccess = true
    this.notAnAttack = true
    this.msgAttack = "{nv:attacker:cast:true} the {i:{nm:skill}} spell."
  }
}

class SpellSummon extends Spell {
  constructor(prototype, data) {
    super(lang.summonSpellPre + ' ' + titleCase(prototype.alias.replace('_', ' ')), data)
    this.noTarget = true
    this.automaticSuccess = true
    this.prototype = prototype
    if (!this.description) this.description = lang.summonSpellDesc(this)

  }
  
  targetEffect(attack) {
    attack.item = cloneObject(this.prototype, attack.attacker.loc)
    attack.item.summonedCountdown = this.duration
    attack.msg(lang.summoning_successful, 1)
  }

}

class SpellInanimate extends Spell {
  constructor(name, data) {
    super(name, data)
    if (!data.noTarget) this.noTarget = true
    this.inanimateTarget = true
  }
  
  getPrimaryTargets(target, attack) { return this.getTargets(attack) }
}







const defaultWeaponAttack = new WeaponAttack("Basic attack", {
  primarySuccess:lang.primarySuccess,
  primaryFailure:lang.primaryFailure,
  modifyOutgoingAttack:function(attack) {},
})

const defaultNaturalAttack = new NaturalAttack("Bash attack", {
  primarySuccess:lang.primarySuccess,
  primaryFailure:lang.primaryFailure,
  modifyOutgoingAttack:function(attack) {},
})

const unarmedAttack = new NaturalAttack("Punch attack", {
  primarySuccess:lang.primarySuccess,
  primaryFailure:lang.primaryFailure,
  damage:'d4',
  offensiveBonus:0,
  modifyOutgoingAttack:function(attack) {},
})


new Effect("Spell cooldown", {
  modifyOutgoingAttack:function(attack, source) {
    log(source)
    if (source.spellCooldown === undefined) return
    if (!attack.skill) return
    if (!attack.skill instanceof Spell) return
    if (!attack.skill.level) return

    log(source.spellCooldown)
    if (source.spellCooldown < 0) {
      source.spellCooldown = source.getSpellCooldownDelay(attack.skill)
    }
    else {
      attack.abort(processText("Cooldown still in progress, cannot cast {show:skill:name} ({number:count:turn} remaining)", {skill:attack.skill, count:source.spellCooldown + 1}))
    }
  },
})

new Effect("Weapon attack cooldown", {
  modifyOutgoingAttack:function(attack, source) {
    if (source.weaponAttackCooldown === undefined) return
    if (!attack.skill) return
    if (attack.skill instanceof Spell) return
    if (!attack.skill.level) return

    if (source.weaponAttackCooldown < 0) {
      source.weaponAttackCooldown = source.getWeaponAttackCooldownDelay(attack.skill)
    }
    else {
      attack.abort('Cooldown still in progress, cannot cast ' + attack.skill.name + " (" + source.weaponAttackCooldown + " turns remaining)")
    }
  },
})

new Effect("Natural attack cooldown", {
  modifyOutgoingAttack:function(attack, source) {
    if (source.naturalAttackCooldown === undefined) return
    if (!attack.skill) return
    if (attack.skill instanceof Spell) return
    if (!attack.skill.level) return

    if (source.naturalAttackCooldown < 0) {
      source.naturalAttackCooldown = source.getNaturalAttackCooldownDelay(attack.skill)
    }
    else {
      attack.abort('Cooldown still in progress, cannot cast ' + attack.skill.name + " (" + source.naturalAttackCooldown + " turns remaining)")
    }
  },
})

new Effect("Limited mana", {
  modifyOutgoingAttack:function(attack, source) {
    if (source.mana === undefined) return
    if (!attack.skill) return
    if (!attack.skill instanceof Spell) return
    if (!attack.skill.level) {
      log('no level')
      log(attack.skill)
      return
    }
    if (source.mana >= attack.skill.level) {
      source.mana -= attack.skill.level
    }
    else {
      attack.abort('Insufficient mana to cast ' + attack.skill.name)
    }
  },
})

new Effect("Fire and forget", {
  modifyOutgoingAttack:function(attack, source) {
    if (!attack.skill) return
    if (!attack.skill instanceof Spell) return
    array.remove(source.skillsLearnt, attack.skill.name)
  },
})